var __provider = (() => {
  var ge = Object.defineProperty, xe = Object.defineProperties;
  var Se = Object.getOwnPropertyDescriptors;
  var H = Object.getOwnPropertySymbols;
  var Y = Object.prototype.hasOwnProperty, Z = Object.prototype.propertyIsEnumerable;
  var J = (e, t, s) => t in e ? ge(e, t, {enumerable: true, configurable: true, writable: true, value: s}) : e[t] = s, g = (e, t) => {
    for (var s in t || (t = {})) Y.call(t, s) && J(e, s, t[s]);
    if (H) for (var s of H(t)) Z.call(t, s) && J(e, s, t[s]);
    return e;
  }, b = (e, t) => xe(e, Se(t));
  var ee = (e, t) => {
    var s = {};
    for (var n in e) Y.call(e, n) && t.indexOf(n) < 0 && (s[n] = e[n]);
    if (e != null && H) for (var n of H(e)) t.indexOf(n) < 0 && Z.call(e, n) && (s[n] = e[n]);
    return s;
  };
  var B = (e, t) => () => (e && (t = e(e = 0)), t);
  var Re = (e, t) => () => (t || e((t = {exports: {}}).exports, t), t.exports);
  var w = (e, t, s) => new Promise((n, i) => {
    var r = l => {
      try {
        c(s.next(l));
      } catch (o) {
        i(o);
      }
    }, a = l => {
      try {
        c(s.throw(l));
      } catch (o) {
        i(o);
      }
    }, c = l => l.done ? n(l.value) : Promise.resolve(l.value).then(r, a);
    c((s = s.apply(e, t)).next());
  });
  function re(e, t) {
    try {
      if (typeof process != "undefined" && process.env && process.env[e]) {
        let s = parseInt(process.env[e], 10);
        return isNaN(s) ? t : s;
      }
    } catch (s) {}
    return t;
  }
  function W(e, t, s = "Operation") {
    return w(this, null, function* () {
      if (!t || t <= 0 || typeof setTimeout == "undefined") return e;
      let n, i = new Promise((r, a) => {
        n = setTimeout(() => a(new Error(`[Timeout] ${s} exceeded ${t}ms`)), t);
      });
      try {
        return yield Promise.race([e, i]);
      } finally {
        clearTimeout(n);
      }
    });
  }
  function F(e) {
    if (!e || typeof e != "string") return true;
    let t = e.toLowerCase();
    return t.includes("test-videos.co.uk") || t.includes("big_buck_bunny") || t.includes("bigbuckbunny") || t.includes("sample-videos.com") || t.includes("example.com") || t.includes("localhost");
  }
  function Te(e) {
    if (!e || typeof e != "string") return false;
    let t = e.toLowerCase();
    return F(t) ? false : /\.(mp4|m3u8|mkv|webm)(\?.*)?$/.test(t) || t.includes("/hls2/") || t.includes("/master.m3u8");
  }
  function ae(e) {
    if (!Number.isFinite(e) || e <= 0) return P;
    let t = V[0], s = Math.abs(e - t);
    for (let n of V) {
      let i = Math.abs(e - n);
      i < s && (s = i, t = n);
    }
    return t;
  }
  function q(e) {
    let t = String(e || "").trim().toLowerCase();
    if (!t) return `${P}p`;
    if (t === "4k" || t === "uhd" || t.includes("2160")) return "2160p";
    if (t.includes("fhd") || t.includes("fullhd") || t.includes("1080")) return "1080p";
    if (t.includes("hd") || t.includes("720")) return "720p";
    let s = t.match(/(\d{3,4})\s*p?/i);
    return s ? `${ae(Number(s[1]))}p` : `${P}p`;
  }
  function $e(e) {
    if (!e || typeof e != "string") return {video: null, audio: null};
    let t = e.split(",").map(i => i.trim()), s = null, n = null;
    for (let i of t) {
      let r = i.split(".")[0].toLowerCase(), a = be[r];
      a && (["H.264", "H.265", "AV1", "VP9"].includes(a) ? s || (s = {codec: a, raw: i}) : ["AAC", "AC3", "EAC3", "Opus"].includes(a) && (n || (n = {codec: a, raw: i})));
    }
    return {video: s, audio: n};
  }
  function Ce(e) {
    let t = ce.get(e);
    return t && Date.now() - t.ts < Ae ? t.data : null;
  }
  function De(e, t) {
    ce.set(e, {data: t, ts: Date.now()});
  }
  function N(e) {
    let s = q(e).toLowerCase().match(/(\d{3,4})p/), n = s ? Number(s[1]) : P, i = ae(n);
    return V.length - 1 - V.indexOf(i);
  }
  function ke(e, t, s, n) {
    let i = [], r = q(t);
    return r && !(e || "").includes(r) && i.push(r), s && s !== "H.264" && i.push(s), n && n > 30 && i.push(`${n}fps`), i.length === 0 ? e : `${e} [${i.join(" ")}]`;
  }
  function Q(e) {
    if (!e || typeof e != "string") return null;
    let t = e.toLowerCase();
    return t.includes(".m3u8") || t.includes("/hls/") || t.includes("/hls2/") || t.includes("master.m3u8") ? "hls" : t.includes(".mp4") ? "mp4" : t.includes(".mkv") ? "mkv" : t.includes(".webm") ? "webm" : null;
  }
  function Me(e) {
    if (e.language) return e.language;
    let s = (e.name || "").match(/\((\w+)\)/);
    if (s) {
      let n = s[1].toUpperCase();
      if (["VF", "VOSTFR", "VO", "VOSTF", "VOA", "VOST"].includes(n)) return n;
    }
    return null;
  }
  function qe(s) {
    return w(this, arguments, function* (e, t = {}) {
      var T, A, C, k, U, E, M;
      if (!e || !e.url || typeof e.url != "string") return [];
      let n = e.url, i = n.toLowerCase();
      if (!i.includes(".m3u8") && !i.includes("/hls/")) return [b(g({}, e), {quality: q(e.quality || "HD"), type: Q(n)})];
      let r = n;
      if (!t.forceRefresh) {
        let h = Ce(r);
        if (h) return h;
      }
      let a = yield x(n, {headers: e.headers || {}});
      if (!a) return [b(g({}, e), {quality: q(e.quality || "HD"), type: "hls"})];
      let c = yield a.text();
      if (!/#EXT-X-STREAM-INF/i.test(c)) return [b(g({}, e), {quality: q(e.quality || "HD"), type: "hls"})];
      let l = c.split(/\r?\n/).map(h => h.trim()).filter(Boolean), o = [];
      for (let h = 0; h < l.length; h++) {
        let u = l[h];
        if (!u.startsWith("#EXT-X-STREAM-INF:")) continue;
        let p = l[h + 1];
        if (!p || p.startsWith("#")) continue;
        let R = (T = u.match(/RESOLUTION=\d+x(\d+)/i)) == null ? undefined : T[1], m = (A = u.match(/FRAME-RATE=([0-9.]+)/i)) == null ? undefined : A[1], v = (C = u.match(/BANDWIDTH=(\d+)/i)) == null ? undefined : C[1], _ = (k = u.match(/CODECS="([^"]+)"/i)) == null ? undefined : k[1], $ = R ? `${R}p` : null;
        if (!$ && v) {
          let L = Number(v);
          L >= 8e6 ? $ = "2160p" : L >= 5e6 ? $ = "1080p" : L >= 25e5 ? $ = "720p" : L >= 12e5 ? $ = "480p" : $ = "360p";
        }
        !$ && m && ($ = `${q(e.quality || "HD")}`);
        let j = $e(_), G = m ? Math.round(parseFloat(m)) : null, X = p;
        try {
          X = new URL(p, n).toString();
        } catch (L) {}
        o.push(b(g({}, e), {url: X, quality: q($ || e.quality || "HD"), type: "hls", codec: ((U = j.video) == null ? undefined : U.codec) || null, audioCodec: ((E = j.audio) == null ? undefined : E.codec) || null, fps: G, bandwidth: v ? parseInt(v) : null, title: ke(e.title || e.name || "Stream", $ || e.quality || "HD", t.includeCodec !== false ? (M = j.video) == null ? undefined : M.codec : null, t.includeFps !== false ? G : null)}));
      }
      if (o.length === 0) return [b(g({}, e), {quality: q(e.quality || "HD"), type: "hls"})];
      let f = [], d = new Set;
      for (let h of o) d.has(h.url) || (d.add(h.url), f.push(h));
      f.sort((h, u) => N(u.quality) - N(h.quality));
      let y = t.maxVariants || f.length, S = f.slice(0, y);
      return De(r, S), S;
    });
  }
  function Ee(e, t) {
    if (!t || !e.length) return e;
    let s = t.toUpperCase();
    return e.some(i => {
      var r;
      return ((r = i.codec) == null ? undefined : r.toUpperCase()) === s;
    }) ? e.filter(i => {
      var r;
      return ((r = i.codec) == null ? undefined : r.toUpperCase()) === s;
    }) : e;
  }
  function Ue(e) {
    return [...e].sort((t, s) => {
      let n = N(s.quality) - N(t.quality);
      if (n !== 0) return n;
      if (t.codec && s.codec) {
        let i = r => te.indexOf(r) >= 0 ? te.indexOf(r) : 99;
        return i(t.codec) - i(s.codec);
      }
      return 0;
    });
  }
  function oe(s) {
    return w(this, arguments, function* (e, t = {}) {
      let n = Array.isArray(e) ? e : [], i = [], r = yield Promise.allSettled(n.map(o => qe(o, t)));
      for (let o = 0; o < r.length; o++) {
        let f = r[o], d = n[o];
        if (f.status === "fulfilled") for (let y of f.value) i.push(y); else d && i.push(b(g({}, d), {quality: q(d.quality || "HD"), type: Q(d.url)}));
      }
      let a = [], c = new Set;
      for (let o of i) o != null && o.url && (F(o.url) || c.has(o.url) || (c.add(o.url), a.push(o)));
      let l = Ue(a);
      return l = l.map(o => b(g({}, o), {type: o.type || Q(o.url), language: Me(o) || o.language || null})), t.preferredCodec ? Ee(l, t.preferredCodec) : l;
    });
  }
  function x(s) {
    return w(this, arguments, function* (e, t = {}) {
      let n = Date.now(), i = 15e3;
      try {
        let r = t, {timeout: a} = r, c = ee(r, ["timeout"]), l = b(g({}, c), {headers: g(g({}, se), c.headers), redirect: "follow"});
        a > 0 && typeof AbortSignal != "undefined" && typeof AbortSignal.timeout != "undefined" && (l.signal = AbortSignal.timeout(a));
        let o = yield fetch(e, l), f = Date.now() - n;
        if (f > i && console.warn(`[safeFetch] Slow request (${f}ms): ${(e || "").slice(0, 120)}`), !o) return null;
        let d = o.status, y = "";
        try {
          y = yield o.text();
        } catch (S) {
          y = "";
        }
        return {text: () => Promise.resolve(y), json: () => w(null, null, function* () {
          try {
            return JSON.parse(y);
          } catch (S) {
            throw S;
          }
        }), ok: o.ok, status: d, url: o.url, headers: o.headers};
      } catch (a) {
        let c = Date.now() - n;
        return c > i && console.warn(`[safeFetch] Slow request failed (${c}ms): ${(e || "").slice(0, 120)}`), null;
      }
    });
  }
  function D(e) {
    try {
      if (!e.includes("p,a,c,k,e,d")) return e;
      let t = r => {
        let a = [], c = 0;
        for (;;) {
          let l = r.indexOf("eval(function(p,a,c,k,e,d)", c);
          if (l === -1) break;
          let o = l, f = 0, d = false, y = false, S = false;
          for (; o < r.length; o++) {
            let T = r[o];
            if (S) {
              S = false;
              continue;
            }
            if (T === "\\") {
              S = true;
              continue;
            }
            if (!y && T === "'" ? d = !d : !d && T === '"' && (y = !y), !(d || y)) {
              if (T === "(") f++; else if (T === ")" && (f--, f === 0)) {
                o++;
                break;
              }
            }
          }
          o > l && a.push(r.slice(l, o)), c = o;
        }
        return a;
      }, s = r => {
        let a = (u, p) => {
          let R = u[p];
          if (R !== "'" && R !== '"') return null;
          let m = p + 1, v = "", _ = false;
          for (; m < u.length; m++) {
            let $ = u[m];
            if (_) {
              v += $, _ = false;
              continue;
            }
            if ($ === "\\") {
              _ = true;
              continue;
            }
            if ($ === R) return {value: v, end: m + 1};
            v += $;
          }
          return null;
        }, c = (u, p) => {
          for (; p < u.length && /\s/.test(u[p]);) p++;
          return p;
        }, l = (u, p) => {
          p = c(u, p);
          let R = u.slice(p).match(/^\d+/);
          return R ? {value: parseInt(R[0], 10), end: p + R[0].length} : null;
        }, o = r.indexOf("}(");
        if (o === -1) return null;
        let f = o + 2;
        f = c(r, f);
        let d = a(r, f);
        if (!d) return null;
        let y = d.value;
        if (f = c(r, d.end), r[f] !== ",") return null;
        let S = l(r, f + 1);
        if (!S) return null;
        let T = S.value;
        if (f = c(r, S.end), r[f] !== ",") return null;
        let A = l(r, f + 1);
        if (!A) return null;
        let C = A.value;
        if (f = c(r, A.end), r[f] !== ",") return null;
        let k = a(r, c(r, f + 1));
        if (!k) return null;
        let U = r.slice(k.end, k.end + 20);
        if (!/\.split\(\s*['"]\|['"]\s*\)/.test(U)) return null;
        let E = k.value.split("|"), M = u => (u < T ? "" : M(parseInt(u / T, 10))) + ((u = u % T) > 35 ? String.fromCharCode(u + 29) : u.toString(36)), h = {};
        for (; C--;) h[M(C)] = E[C] || M(C);
        return y.replace(/\b\w+\b/g, u => h[u] || u);
      }, n = e, i = t(e);
      for (let r of i) try {
        let a = s(r);
        a && (n = n.replace(r, a));
      } catch (a) {}
      return n;
    } catch (t) {
      return e;
    }
  }
  function Fe(e) {
    return w(this, null, function* () {
      try {
        let t = yield x(e, {headers: {Referer: "https://video.sibnet.ru/"}});
        if (!t) return {url: e};
        let s = yield t.text(), n = s.match(/file\s*:\s*["']([^"']*\.mp4[^"']*)['"]/i) || s.match(/src\s*:\s*["']([^"']*\.mp4[^"']*)['"]/i) || s.match(/["']((?:https?:)?\/\/[^"'\s]+\.mp4[^"'\s]*)["']/i);
        if (n) {
          let i = n[1];
          return i.startsWith("//") ? i = "https:" + i : i.startsWith("/") && (i = "https://video.sibnet.ru" + i), {url: i, headers: {Referer: "https://video.sibnet.ru/"}};
        }
      } catch (t) {}
      return {url: e};
    });
  }
  function Oe(e) {
    return w(this, null, function* () {
      try {
        let s = [e.replace(/vidmoly\.(net|to|ru|is|biz)/, "vidmoly.me"), e], n = [...new Set(s)], i = {Referer: "https://vidmoly.me/", Origin: "https://vidmoly.me"};
        for (let r of n) try {
          let a = yield x(r, {headers: i});
          if (!a) continue;
          let c = yield a.text();
          (c.includes("p,a,c,k,e,d") || c.includes("eval(function")) && (c = D(c));
          let l = c.match(/file\s*:\s*["']([^"']+\.(?:m3u8|mp4)[^"']*)["']/i) || c.match(/sources\s*:\s*\[["']([^"']+\.(?:m3u8|mp4)[^"']*)["']\]/i) || c.match(/["'](https?:\/\/[^"']+\.(?:m3u8|mp4)[^"']*)["']/i);
          if (l) return {url: l[1], headers: {Referer: "https://vidmoly.me/"}};
          let o = c.match(/window\.location\.replace\(['"]([^'"]+)['"]\)/) || c.match(/window\.location\.href\s*=\s*['"]([^'"]+)['"]/);
          if (o && o[1] !== r && (a = yield x(o[1], {headers: i}), a)) {
            c = yield a.text(), (c.includes("p,a,c,k,e,d") || c.includes("eval(function")) && (c = D(c));
            let f = c.match(/file\s*:\s*["']([^"']+\.(?:m3u8|mp4)[^"']*)["']/i) || c.match(/sources\s*:\s*\[["']([^"']+\.(?:m3u8|mp4)[^"']*)["']\]/i) || c.match(/["'](https?:\/\/[^"']+\.(?:m3u8|mp4)[^"']*)["']/i);
            if (f) return {url: f[1], headers: {Referer: "https://vidmoly.me/"}};
          }
        } catch (a) {}
      } catch (t) {}
      return {url: e};
    });
  }
  function _e(e) {
    return w(this, null, function* () {
      var r;
      let t = e.replace(/^https?:\/\/[^/]+/, ""), s = ((r = e.match(/^https?:\/\/([^/]+)/)) == null ? undefined : r[1]) || "uqload.co", n = [s];
      s.endsWith(".bz") && n.push("uqload.co", "uqload.to"), s.endsWith(".to") && n.push("uqload.co");
      let i = [...new Set(n)];
      return new Promise(a => {
        let c = 0, l = false, o = f => w(null, null, function* () {
          try {
            let d = `https://${f}${t}`, y = `https://${f}/`, S = yield x(d, {headers: b(g({}, se), {Referer: y})});
            if (S) {
              let T = yield S.text(), A = T.match(/sources\s*:\s*\[["']([^"']+\.(?:mp4|m3u8))["']\]/) || T.match(/file\s*:\s*["']([^"']+\.(?:mp4|m3u8))["']/);
              if (A && !l) {
                l = true, a({url: A[1], headers: {Referer: y}});
                return;
              }
            }
          } catch (d) {}
          c++, c === i.length && !l && a({url: e});
        });
        i.forEach(o);
      });
    });
  }
  function Le(e) {
    return w(this, null, function* () {
      try {
        let t = yield x(e);
        if (!t) return {url: e};
        let s = yield t.text(), n = e, i = s.match(/window\.location\.href\s*=\s*['"]([^'"]+)['"]/);
        if (i) {
          n = i[1];
          let a = yield x(n);
          a && (s = yield a.text());
        }
        (s.includes("p,a,c,k,e,d") || s.includes("eval(function")) && (s = D(s));
        let r = s.match(/'hls'\s*:\s*'([^']+)'/) || s.match(/"hls"\s*:\s*"([^"]+)"/) || s.match(/file\s*:\s*["']([^"']+\.(?:m3u8|mp4)[^"']*)["']/i) || s.match(/sources\s*:\s*\[["']([^"']+\.(?:m3u8|mp4)[^"']*)["']\]/i) || s.match(/https?:\/\/[^"']+\.m3u8[^"']*/);
        if (r) {
          let a = r[1] || r[0];
          return a.includes("base64") && (a = ie(a.split(",")[1] || a)), F(a) ? {url: e} : {url: a, headers: {Referer: n}};
        }
      } catch (t) {}
      return {url: e};
    });
  }
  function He(e) {
    return w(this, null, function* () {
      try {
        let t = yield x(e);
        if (!t) return {url: e};
        let s = yield t.text();
        s.includes("p,a,c,k,e,d") && (s = D(s));
        let n = s.match(/robotlink['"]\)\.innerHTML\s*=\s*['"]([^'"]+)['"]\s*\+\s*([^;]+)/);
        if (n) {
          let i = "https:" + n[1], r = n[2].split("+");
          for (let a of r) {
            let c = a.match(/['"]([^'"]+)['"]/);
            if (c) {
              let l = c[1], o = a.match(/substring\((\d+)\)/);
              o && (l = l.substring(parseInt(o[1]))), i += l;
            }
          }
          return {url: i, headers: {Referer: "https://streamtape.com/"}};
        }
      } catch (t) {}
      return {url: e};
    });
  }
  function Ve(e) {
    return w(this, null, function* () {
      try {
        if (e.includes("daisukianime")) {
          let r = e.match(/[?&]id=([a-z0-9]+)/i);
          r && (e = `https://sendvid.com/embed/${r[1]}`);
        }
        let t = e.includes("/embed/") ? e : e.replace(/sendvid\.com\/([a-z0-9]+)/i, "sendvid.com/embed/$1"), s = yield x(t, {headers: {Referer: "https://sendvid.com/"}});
        if (!s) return {url: e};
        let n = yield s.text(), i = n.match(/video_source\s*:\s*["']([^"']+\.mp4[^"']*)["|']/) || n.match(/source\s+src=["']([^"']+\.mp4[^"']*)["|']/) || n.match(/<source[^>]+src=["']([^"']+\.(?:mp4|m3u8)[^"']*)["']/) || n.match(/file\s*:\s*["']([^"']+\.(?:mp4|m3u8)[^"']*)["|']/) || n.match(/["'](https?:\/\/[^"']+\.mp4[^"']*)["']/);
        if (i) return {url: i[1], headers: {Referer: "https://sendvid.com/"}};
      } catch (t) {}
      return {url: e};
    });
  }
  function Pe(e) {
    return w(this, null, function* () {
      try {
        let t = yield x(e);
        if (!t) return {url: e};
        let s = yield t.text();
        s.includes("p,a,c,k,e,d") && (s = D(s));
        let n = s.match(/sources\s*:\s*\[["']([^"']+\.(?:m3u8|mp4)[^"']*)["']\]/) || s.match(/file\s*:\s*["']([^"']+\.(?:m3u8|mp4)[^"']*)["']/);
        if (n) {
          let i = n[1];
          return i.includes("base64") && (i = ie(i.split(",")[1] || i)), {url: i, headers: {Referer: e}};
        }
      } catch (t) {}
      return {url: e};
    });
  }
  function Ne(e) {
    return w(this, null, function* () {
      try {
        let t = yield x(e);
        if (!t) return {url: e};
        let n = (yield t.text()).match(/["'](https?:\/\/[^"']+\.m3u8[^"']*)["']/);
        if (n) return {url: n[1], headers: {Referer: e}};
      } catch (t) {}
      return {url: e};
    });
  }
  function We(e) {
    return w(this, null, function* () {
      var t;
      try {
        let s = ((t = e.match(/https?:\/\/([^\/]+)/)) == null ? undefined : t[1]) || "dood.to", n = yield x(e);
        if (!n) return {url: e};
        let i = yield n.text();
        i.includes("eval(function(p,a,c,k,e,d)") && (i = D(i));
        let r = i.match(/\$\.get\(['"]\/pass_md5\/([^'"]+)['"]/);
        if (r) {
          let a = r[1], c = `https://${s}/pass_md5/${a}`, l = yield x(c, {headers: {Referer: e}});
          if (l && l.ok) {
            let o = yield l.text(), f = Math.random().toString(36).substring(2, 12);
            return {url: o + f + "?token=" + a + "&expiry=" + Date.now(), headers: {Referer: `https://${s}/`}};
          }
        }
      } catch (s) {}
      return {url: e};
    });
  }
  function Ie(e) {
    return w(this, null, function* () {
      try {
        let t = yield x(e, {headers: {Referer: "https://www.myvi.ru/"}});
        if (!t) return {url: e};
        let s = yield t.text();
        s.includes("eval(function(p,a,c,k,e,d)") && (s = D(s));
        let n = s.match(/["'](?:file|src|url|stream_url)["']\s*:\s*["']([^"']+\.(?:mp4|m3u8)[^"']*)["']/) || s.match(/["'](https?:\/\/[^"']+\.(?:mp4|m3u8)[^"']*)["']/) || s.match(/source\s+src=["']([^"']+\.(?:mp4|m3u8)[^"']*)/);
        if (n) return {url: n[1], headers: {Referer: "https://www.myvi.ru/"}};
        let i = e.match(/\/(?:embed\/|watch\/|video\/)([a-zA-Z0-9_-]+)/);
        if (i) {
          let r = `https://www.myvi.ru/api/video/${i[1]}`, a = yield x(r, {headers: {Referer: e}});
          if (a) {
            let l = (yield a.text()).match(/["'](?:url|src|file)["']\s*:\s*["']([^"']+\.(?:mp4|m3u8)[^"']*)["']/);
            if (l) return {url: l[1], headers: {Referer: "https://www.myvi.ru/"}};
          }
        }
      } catch (t) {}
      return {url: e};
    });
  }
  function ze(e) {
    return w(this, null, function* () {
      var t;
      try {
        let s = ((t = e.match(/^https?:\/\/[^/]+/)) == null ? undefined : t[0]) || "https://younetu.org", n = yield x(e, {headers: {Referer: s + "/"}});
        if (!n) return {url: e};
        let i = yield n.text();
        (i.includes("p,a,c,k,e,d") || i.includes("eval(function")) && (i = D(i));
        let r = i.match(/src\s*:\s*["']([^"']+\.(?:m3u8|mp4)[^"']*)["']/i) || i.match(/file\s*:\s*["']([^"']+\.(?:m3u8|mp4)[^"']*)["']/i) || i.match(/sources\s*:\s*\[["']([^"']+\.(?:m3u8|mp4)[^"']*)["']\]/i) || i.match(/["'](https?:\/\/[^"']+\.(?:m3u8|mp4)[^"']*)["']/i);
        if (r) return {url: r[1], headers: {Referer: s + "/"}};
      } catch (s) {}
      return {url: e};
    });
  }
  function je(e) {
    return w(this, null, function* () {
      try {
        let t = yield x(e, {headers: {Referer: "https://vidoza.net/"}});
        if (!t) return {url: e};
        let s = yield t.text(), n = s.match(/src\s*:\s*["']([^"']+\.(?:mp4|m3u8)[^"']*)["']/i) || s.match(/file\s*:\s*["']([^"']+\.(?:mp4|m3u8)[^"']*)["']/i) || s.match(/["'](https?:\/\/[^"']+\.(?:mp4|m3u8)[^"']*)["']/i);
        if (n) return {url: n[1], headers: {Referer: "https://vidoza.net/"}};
      } catch (t) {}
      return {url: e};
    });
  }
  function Be(e) {
    return w(this, null, function* () {
      try {
        let t = yield x(e);
        if (!t) return {url: e};
        let s = yield t.text();
        s.includes("p,a,c,k,e,d") && (s = D(s));
        let n = s.match(/file\s*:\s*["']([^"']+\.(?:mp4|m3u8)[^"']*)["']/);
        if (n) return {url: n[1], headers: {Referer: e}};
      } catch (t) {}
      return {url: e};
    });
  }
  function ne(e) {
    return w(this, null, function* () {
      var t;
      try {
        let s = ((t = e.match(/^https?:\/\/[^/]+/)) == null ? undefined : t[0]) || e, n = yield x(e, {headers: {Referer: s + "/"}});
        if (!n) return {url: e};
        let i = yield n.text();
        (i.includes("p,a,c,k,e,d") || i.includes("eval(function")) && (i = D(i));
        let r = i.match(/file\s*:\s*["']([^"']+\.(?:m3u8|mp4)[^"']*)["']/i) || i.match(/sources\s*:\s*\[[^\]]*?["'](https?:\/\/[^"']+\.(?:m3u8|mp4)[^"']*)["']/i) || i.match(/["'](https?:\/\/[^"']+\.(?:m3u8|mp4)[^"']*)["']/i);
        if (r) return {url: r[1], headers: {Referer: s + "/"}};
      } catch (s) {}
      return {url: e};
    });
  }
  function Qe(e) {
    return w(this, null, function* () {
      return {url: e};
    });
  }
  function Ke(e) {
    return w(this, null, function* () {
      try {
        let t = yield x(e, {headers: {Referer: "https://up4fun.top/"}});
        if (!t) return null;
        let s = yield t.text(), n = s.match(/["'](https?:\/\/[^"']+\.(?:m3u8|mp4)[^"']*)["']/i) || s.match(/file\s*:\s*["']([^"']+\.(?:m3u8|mp4)[^"']*)["']/i);
        if (n) return {url: n[1], headers: {Referer: "https://up4fun.top/"}};
      } catch (t) {}
      return null;
    });
  }
  function K(e, t = 0) {
    return w(this, null, function* () {
      var i;
      if (t > 1) return b(g({}, e), {isDirect: false});
      let s = e.url, n = s.toLowerCase();
      if (!s || s.includes("google-analytics") || s.includes("doubleclick")) return null;
      if (Te(s)) return b(g({}, e), {isDirect: true});
      try {
        let r = null;
        if (n.includes("sibnet.ru") ? r = yield Fe(s) : n.includes("vidmoly.") ? r = yield Oe(s) : n.includes("uqload.") || n.includes("oneupload.") ? r = yield _e(s) : n.includes("voe") || n.includes("weneverbeenfree") || n.includes("maryspecialwatch") || n.includes("charlestoughrace") || n.includes("sandratableother") ? r = yield Le(s) : n.includes("streamtape.com") || n.includes("stape") ? r = yield He(s) : n.includes("dood") || n.includes("ds2play") || n.includes("bigwar5") ? r = yield We(s) : n.includes("moonplayer") || n.includes("filemoon") ? r = yield Be(s) : n.includes("younetu.") || n.includes("netu.") ? r = yield ze(s) : n.includes("vidoza.") ? r = yield je(s) : n.includes("sendvid.") || n.includes("daisukianime") ? r = yield Ve(s) : n.includes("myvi.") || n.includes("mytv.") ? r = yield Ie(s) : n.includes("fsvid.lol") || n.includes("vidzy.live") || n.includes("vidstream.pro") || n.includes("vidcdn.") || n.includes("kakaflix.") ? r = yield ne(s) : n.includes("luluvid.") || n.includes("lulustream.") || n.includes("luluvdo.") || n.includes("wishonly.") || n.includes("veev.") ? r = yield ne(s) : n.includes("lulu.") ? r = yield Pe(s) : n.includes("hgcloud.") || n.includes("savefiles.") ? r = yield Ne(s) : n.includes("down-paradise.") || n.includes("ww1.down-paradise.") ? r = yield Qe(s) : n.includes("up4fun.") && (r = yield Ke(s)), r && r.url !== s && !F(r.url)) return b(g({}, e), {url: r.url, headers: g(g({}, e.headers), r.headers || {}), isDirect: true, originalUrl: s});
        let a = n.includes("up4fun.") || n.includes("down-paradise.") || n.includes("getvid.club");
        if (!r || r.url === s) {
          if (a) return b(g({}, e), {isDirect: false});
          let c = yield x(s, {headers: e.headers});
          if (c) {
            let l = yield c.text();
            l.includes("p,a,c,k,e,d") && (l = D(l));
            let o = l.match(/window\.location\.(?:href|replace)\s*=\s*['"]([^'"]+)['"]/);
            if (o && o[1] !== s) {
              let d = yield x(o[1], {headers: e.headers});
              d && (l = yield d.text(), l.includes("p,a,c,k,e,d") && (l = D(l)));
            }
            let f = l.match(/https?:\/\/[^"']+\.m3u8[^"']*/) || l.match(/https?:\/\/[^"']+\.mp4[^"']*/) || l.match(/file\s*:\s*["']([^"']+\.(?:m3u8|mp4)[^"']*)["']/i) || l.match(/sources\s*:\s*\[["']([^"']+\.(?:m3u8|mp4)[^"']*)["']\]/i) || l.match(/'hls'\s*:\s*'([^']+)'/) || l.match(/"hls"\s*:\s*"([^"]+)"/);
            if (f) {
              let d = f[1] || f[0];
              d.startsWith("//") && (d = "https:" + d);
              let y = d.match(/\.(css|js|html|php|jpg|png|gif|svg)(\?.*)?$/i);
              d.startsWith("http") && !d.includes(Ge) && !y && !F(d) && (r = {url: d});
            }
            if (!r) {
              let d = l.match(/<iframe\s+[^>]*src=["']([^"']+)["']/i);
              if (d) {
                let y = d[1];
                if (y.startsWith("//") && (y = "https:" + y), y.startsWith("/")) {
                  let S = (i = s.match(/^https?:\/\/[^\/]+/)) == null ? undefined : i[0];
                  S && (y = S + y);
                }
                if (y.startsWith("http") && y !== s) return console.log(`[Resolver] Peeling: Found nested iframe -> ${y}`), yield K(b(g({}, e), {url: y}), t + 1);
              }
            }
          }
        }
        if (r && r.url !== s && r.url.startsWith("http") && !F(r.url)) return b(g({}, e), {url: r.url, headers: g(g({}, e.headers), r.headers || {}), isDirect: true, originalUrl: s});
      } catch (r) {}
      return b(g({}, e), {isDirect: false});
    });
  }
  var se, ie, te, V, P, be, ce, Ae, Ge, I = B(() => {
    se = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36", "Accept-Encoding": "identity"}, ie = e => {
      try {
        return atob(e);
      } catch (t) {
        return e;
      }
    }, te = ["AV1", "H.265", "H.264", "VP9"];
    V = [2160, 1080, 720, 480, 360, 240], P = 720;
    be = {avc1: "H.264", h264: "H.264", hev1: "H.265", hvc1: "H.265", h265: "H.265", av01: "AV1", av1: "AV1", vp9: "VP9", vp09: "VP9", mp4a: "AAC", "ac-3": "AC3", "ec-3": "EAC3", opus: "Opus"};
    ce = new Map, Ae = 12e4;
    Ge = "googletagmanager";
  });
  function le(s) {
    return w(this, arguments, function* (e, t = {}) {
      console.log(`[Movix] Fetching: ${e}`);
      try {
        let n = yield x(e, g({timeout: 15e3, headers: g(g({}, Xe), t.headers || {})}, t));
        if (!n || !n.ok) {
          let i = n && typeof n.status == "number" ? n.status : "no-response";
          return console.log(`[Movix] HTTP ${i} for ${e}`), null;
        }
        try {
          return yield n.json();
        } catch (i) {
          let r = yield n.text();
          return console.log(`[Movix] JSON parse error for ${e}. Content length: ${String(r && r.length)}`), null;
        }
      } catch (n) {
        return console.log(`[Movix] Fetch error for ${e}: ${n.message}`), null;
      }
    });
  }
  var Xe, ue = B(() => {
    I();
    Xe = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36", Accept: "application/json, text/plain, */*", "Accept-Language": "fr-FR,fr;q=0.9,en-US;q=0.8,en;q=0.7", Origin: "https://movix.cash", Referer: "https://movix.cash/", "Sec-Fetch-Dest": "empty", "Sec-Fetch-Mode": "cors", "Sec-Fetch-Site": "same-site", DNT: "1"};
  });
  function Ze(e) {
    try {
      return new URL(e).origin;
    } catch (t) {
      return "https://movix.cash";
    }
  }
  function fe(e) {
    let t = (e || "").toLowerCase();
    return t === "vff" || t === "vfq" || t === "vf" || t.includes("french") ? "VF" : t === "vostfr" || t === "vost" || t.includes("vostfr") ? "VOSTFR" : t === "default" || t === "multi" ? "MULTI" : (e || "VF").toUpperCase();
  }
  function de(e, t) {
    let s = (e || "").toLowerCase(), n = 0, i = (t || "").toUpperCase();
    i === "VF" || i === "VFF" || i === "VFQ" ? n += 0 : i === "DEFAULT" || i === "MULTI" ? n += 10 : i === "VOSTFR" ? n += 20 : n += 30;
    let r = Je.some(c => s.includes(c)), a = Ye.some(c => s.includes(c));
    return r ? n += 100 : a ? n += 0 : n += 50, n;
  }
  function z(e, t, s, n, i, r) {
    if (!i || typeof i != "string") return;
    let a = Ze(i);
    e.push({name: "Movix", title: `[${fe(n)}] ${t} - ${s || "Player"}`, url: i, quality: r || "HD", language: fe(n), headers: {Referer: a + "/", Origin: a, "User-Agent": me}});
  }
  function he(e) {
    if (!e || typeof e != "string") return false;
    let t = e.toLowerCase();
    return t.includes("test-videos.co.uk") || t.includes("sample-videos.com") || t.includes("big_buck_bunny") || t.includes("/embed") || t.includes("/e/") || t.includes("iframe") || t.includes("index.php") ? false : !!(t.includes(".m3u8") || t.includes(".mp4") || t.includes(".mkv") || t.includes(".webm") || t.includes(".ts") || t.includes("manifest") || t.includes("playlist") || t.includes("/hls/"));
  }
  function pe(e) {
    return w(this, null, function* () {
      let t = null;
      if (he(e.url)) t = b(g({}, e), {isDirect: true}); else try {
        t = yield W(K(e), 4e3);
      } catch (s) {}
      return !t || !t.url || !t.isDirect || !he(t.url) ? null : {name: t.name || e.name, title: t.title || e.title, url: t.url, quality: t.quality || "HD", isDirect: true, headers: b(g({}, t.headers), {"User-Agent": me})};
    });
  }
  function et(e) {
    return w(this, null, function* () {
      try {
        let t = yield le(e);
        return !t || t.error ? null : t;
      } catch (t) {
        return null;
      }
    });
  }
  function ye(e, t, s, n) {
    return w(this, null, function* () {
      var E, M;
      let i = [];
      if (!e) return console.log("[Movix] Missing tmdbId"), i;
      let r = t === "movie", a = Number(n) || 1, c = r ? [`${O}/api/fstream/movie/${e}`, `${O}/api/wiflix/movie/${e}`, `${O}/api/cpasmal/movie/${e}`] : [`${O}/api/fstream/tv/${e}/season/${Number(s) || 1}`, `${O}/api/wiflix/tv/${e}/${Number(s) || 1}`, `${O}/api/cpasmal/tv/${e}/${Number(s) || 1}/${a}`], l = yield Promise.allSettled(c.map(h => et(h))), o = false;
      for (let h of l) {
        if (h.status !== "fulfilled" || !h.value) continue;
        o = true;
        let u = h.value;
        if (u.players) for (let p of Object.keys(u.players)) {
          let R = u.players[p];
          if (Array.isArray(R)) for (let m of R) z(i, "FStream", m == null ? undefined : m.player, p, m == null ? undefined : m.url, m == null ? undefined : m.quality);
        }
        if (u.links) for (let p of Object.keys(u.links)) {
          let R = u.links[p];
          if (Array.isArray(R)) for (let m of R) z(i, "Wiflix", (m == null ? undefined : m.name) || (m == null ? undefined : m.player), p, m == null ? undefined : m.url, m == null ? undefined : m.quality);
        }
        if (!r) {
          let p = ((E = u == null ? undefined : u.episodes) == null ? undefined : E[String(a)]) || ((M = u == null ? undefined : u.episodes) == null ? undefined : M[a]);
          if (!p || typeof p != "object") continue;
          if (p.languages) for (let R of Object.keys(p.languages)) {
            let m = p.languages[R];
            if (Array.isArray(m)) for (let v of m) z(i, "FStream", v == null ? undefined : v.player, R, v == null ? undefined : v.url, v == null ? undefined : v.quality);
          }
          for (let R of ["vf", "vostfr", "vo", "VFF", "VFQ", "VOSTFR", "Default"]) {
            let m = p[R];
            if (Array.isArray(m)) for (let v of m) z(i, "Wiflix", (v == null ? undefined : v.name) || (v == null ? undefined : v.player), R, v == null ? undefined : v.url, v == null ? undefined : v.quality);
          }
        }
      }
      if (o || console.log("[Movix] No streams found from any source"), i.length === 0) return [];
      let f = new Set, d = [];
      for (let h of i) f.has(h.url) || (f.add(h.url), d.push(h));
      d.sort((h, u) => de(h.url, h.language) - de(u.url, u.language));
      let y = 3, S = 2, T = [], A = new Set, C = d.slice(0, y), k = C.slice(0, S), U = yield Promise.allSettled(k.map(h => pe(h)));
      for (let h of U) h.status !== "fulfilled" || !h.value || A.has(h.value.url) || (A.add(h.value.url), T.push(h.value));
      if (T.length < 2 && C.length > S) {
        let h = C.slice(S, y), u = yield Promise.allSettled(h.map(p => pe(p)));
        for (let p of u) p.status !== "fulfilled" || !p.value || A.has(p.value.url) || (A.add(p.value.url), T.push(p.value));
      }
      return console.log(`[Movix] Total: ${d.length} streams, ${T.length} playable (resolved ${C.length})`), T;
    });
  }
  var O, me, Je, Ye, we = B(() => {
    ue();
    I();
    O = "https://api.movix.cloud", me = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36", Je = ["up4fun", "dood", "doodstream", "moonplayer", "filemoon", "streamtape", "stape"], Ye = ["voe", "uqload", "fsvid", "vidzy", "netu", "younetu", "sendvid", "sibnet"];
  });
  var st = Re((yt, ve) => {
    we();
    I();
    var tt = re("NUVIO_TIMEOUT_MOVIX", 6e4);
    function nt(e, t, s, n) {
      return w(this, null, function* () {
        var r;
        let i = `Movix ${t} ${e} S${s}E${n}`;
        console.log(`[Movix] Request: ${i}`);
        try {
          let a = yield W(ye(e, t, s, n), tt, i), c = yield oe(a, {includeCodec: true});
          return console.log(`[Movix] Found ${c.length} streams`), c;
        } catch (a) {
          return (r = a.message) != null && r.includes("[Timeout]") ? console.warn(`[Movix] ${a.message}`) : console.error(`[Movix] Error: ${a.message}`), [];
        }
      });
    }
    ve.exports = {getStreams: nt};
  });
  return st();
})();
if (typeof module !== "undefined" && module.exports) {
  module.exports = __provider;
}
if (__provider && __provider.getStreams) {
  if (typeof globalThis !== "undefined") {
    globalThis.getStreams = __provider.getStreams;
  }
  if (typeof global !== "undefined") {
    global.getStreams = __provider.getStreams;
  }
  if (typeof self !== "undefined") {
    self.getStreams = __provider.getStreams;
  }
}
