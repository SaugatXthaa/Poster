package com.cncverse;

import com.cncverse.DoFlixProvider;
import com.lagradost.cloudstream3.utils.ExtractorLink;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;

/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: DoFlixProvider.kt */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lcom/lagradost/cloudstream3/utils/ExtractorLink;"}, k = 3, mv = {2, 3, 0}, xi = 48)
@DebugMetadata(c = "com.cncverse.DoFlixProvider$loadLinks$3$1", f = "DoFlixProvider.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, nl = {}, s = {}, v = 2)
/* loaded from: classes.dex */
public final class DoFlixProvider$loadLinks$3$1 extends SuspendLambda implements Function2<ExtractorLink, Continuation<? super Unit>, Object> {
    final /* synthetic */ DoFlixProvider.StreamLink $link;
    private /* synthetic */ Object L$0;
    int label;
    final /* synthetic */ DoFlixProvider this$0;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public DoFlixProvider$loadLinks$3$1(DoFlixProvider doFlixProvider, DoFlixProvider.StreamLink streamLink, Continuation<? super DoFlixProvider$loadLinks$3$1> continuation) {
        super(2, continuation);
        this.this$0 = doFlixProvider;
        this.$link = streamLink;
    }

    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
        Continuation<Unit> doFlixProvider$loadLinks$3$1 = new DoFlixProvider$loadLinks$3$1(this.this$0, this.$link, continuation);
        doFlixProvider$loadLinks$3$1.L$0 = obj;
        return doFlixProvider$loadLinks$3$1;
    }

    public final Object invoke(ExtractorLink extractorLink, Continuation<? super Unit> continuation) {
        return create(extractorLink, continuation).invokeSuspend(Unit.INSTANCE);
    }

    public final Object invokeSuspend(Object obj) {
        int qualityValue;
        ExtractorLink extractorLink = (ExtractorLink) this.L$0;
        IntrinsicsKt.getCOROUTINE_SUSPENDED();
        switch (this.label) {
            case 0:
                ResultKt.throwOnFailure(obj);
                extractorLink.setReferer("https://molop.art/");
                qualityValue = this.this$0.getQualityValue(this.$link.getQuality());
                extractorLink.setQuality(qualityValue);
                return Unit.INSTANCE;
            default:
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
    }
}
