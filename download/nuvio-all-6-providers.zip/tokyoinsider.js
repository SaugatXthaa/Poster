// TokyoInsider Scraper for Nuvio Local Scrapers
// Rewritten 2026-08-16 from nuvio-plugins/providers/tokyoinsider.js
//
// The original tokyoinsider.js failed because every endpoint of
// www.tokyoinsider.com (except the bare homepage) is protected by a
// Cloudflare "I'm Under Attack" / Turnstile challenge. Node's fetch,
// curl, and even cloudscraper all receive a "Just a moment..." 403 page.
//
// This rewrite works around it by:
//
//   1. Using the static /upload/autocomplete.js index (a 421KB file
//      listing every anime + URL on the site) to resolve the anime
//      URL from a title search. This file is served as a static asset
//      and is NOT behind the Cloudflare challenge.
//   2. Shelling out to a Python helper that uses Playwright (headless
//      Chromium) to actually load the anime page. Playwright can solve
//      the Cloudflare Turnstile challenge because it runs a real
//      browser engine. The helper extracts the page HTML and writes
//      it to stdout, which we parse for download links.
//   3. Falls back to curl if Playwright is not available (in which
//      case the Cloudflare challenge will likely fail and 0 streams
//      will be returned, but the code remains functional).
//
// This scraper supports 4K (2160p) streams when TokyoInsider has them.
// Most anime on TI max out at 1080p, but some movies and recent
// releases do have 2160p encodes.

"use strict";

var { execFile } = require("child_process");
var path = require("path");

var PROVIDER_NAME = "TokyoInsider";
var BASE_URL = "https://www.tokyoinsider.com";
var TMDB_API_KEY = "1c29a5198ee1854bd5eb45dbe8d17d92";
var TMDB_BASE_URL = "https://api.themoviedb.org/3";
var ANILIST_API_URL = "https://graphql.anilist.co";

var USER_AGENT =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
  "(KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36";

// Path to the Python helper that uses Playwright to bypass Cloudflare.
var PLAYWRIGHT_HELPER = path.join(
  path.dirname(__filename) || "/home/z/my-project/scripts",
  "tokyoinsider_cf_helper.py"
);

// ===== HTTP =====

function curlAvailable() {
  try {
    require("child_process").execSync("curl --version", {
      stdio: "ignore",
      timeout: 2000
    });
    return true;
  } catch (e) {
    return false;
  }
}

var _curlOk = null;

function httpGet(url, extraHeaders) {
  var headers = Object.assign(
    {
      "User-Agent": USER_AGENT,
      Accept: "text/html,application/xhtml+xml,*/*;q=0.8",
      "Accept-Language": "en-US,en;q=0.9"
    },
    extraHeaders || {}
  );

  if (_curlOk === null) _curlOk = curlAvailable();

  if (_curlOk) {
    return new Promise(function (resolve, reject) {
      var args = [
        "-sSk",
        "--max-time", "20",
        "-L",
        "--compressed",
        "-A", headers["User-Agent"],
        "-H", "Accept: " + headers["Accept"],
        "-H", "Accept-Language: " + headers["Accept-Language"]
      ];
      if (headers["Referer"]) args.push("-H", "Referer: " + headers["Referer"]);
      args.push(url);

      execFile("curl", args, {
        encoding: "utf8",
        maxBuffer: 20 * 1024 * 1024,
        timeout: 25000,
        windowsHide: true
      }, function (err, stdout) {
        if (err) {
          reject(new Error("curl failed for " + url + ": " + err.message));
          return;
        }
        if (!stdout || stdout.length < 1) {
          reject(new Error("Empty response from curl for " + url));
          return;
        }
        resolve(stdout);
      });
    });
  }

  return fetch(url, { headers: headers, redirect: "follow" }).then(function (res) {
    if (!res.ok) throw new Error("HTTP " + res.status + " for " + url);
    return res.text();
  });
}

// Fetch a TokyoInsider anime page by routing through a Python/Playwright
// helper. The helper solves the Cloudflare Turnstile and prints the
// final page HTML to stdout.
function fetchViaPlaywright(url) {
  return new Promise(function (resolve, reject) {
    execFile(
      "python3",
      [PLAYWRIGHT_HELPER, url],
      {
        encoding: "utf8",
        maxBuffer: 30 * 1024 * 1024,
        timeout: 120000,
        windowsHide: true
      },
      function (err, stdout, stderr) {
        if (err) {
          var msg = "Playwright helper failed for " + url + ": " + err.message;
          if (stderr) msg += "\nstderr: " + stderr.slice(0, 500);
          reject(new Error(msg));
          return;
        }
        if (!stdout || stdout.length < 100) {
          reject(new Error("Playwright helper returned empty output for " + url));
          return;
        }
        resolve(stdout);
      }
    );
  });
}

// ===== TMDB + AniList =====

function getTMDBDetails(tmdbId, mediaType) {
  var type = mediaType === "tv" ? "tv" : "movie";
  var url = TMDB_BASE_URL + "/" + type + "/" + tmdbId + "?api_key=" + TMDB_API_KEY;
  return httpGet(url)
    .then(function (body) {
      var d = JSON.parse(body);
      if (!d || d.success === false) return null;
      return {
        title: type === "tv" ? d.name : d.title,
        originalTitle: type === "tv" ? d.original_name : d.original_title,
        year: ((d.first_air_date || d.release_date || "") + "").substring(0, 4),
        mediaType: type
      };
    })
    .catch(function () { return null; });
}

function getAniListDetails(title, year) {
  var query =
    "query ($search: String, $year: Int, $type: MediaType) {" +
    "  Media(search: $search, seasonYear: $year, type: $type) {" +
    "    id title { romaji english native }" +
    "  }" +
    "}";
  var variables = { search: title, year: year ? parseInt(year, 10) : null, type: "ANIME" };
  return fetch(ANILIST_API_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify({ query: query, variables: variables })
  })
    .then(function (r) { return r.json(); })
    .then(function (data) {
      if (data && data.data && data.data.Media) {
        var t = data.data.Media.title;
        return { romaji: t.romaji, english: t.english, native: t.native };
      }
      return null;
    })
    .catch(function () { return null; });
}

// ===== AUTOCOMPLETE INDEX =====
//
// /upload/autocomplete.js is a static file containing a JS array of
// [title, url] pairs for every anime on the site. It's served without
// the Cloudflare challenge, so curl can fetch it directly.

var autocompleteCache = { data: null, ts: 0 };
var AUTOCOMPLETE_TTL = 24 * 60 * 60 * 1000;

function getAutocompleteIndex() {
  if (autocompleteCache.data && Date.now() - autocompleteCache.ts < AUTOCOMPLETE_TTL) {
    return Promise.resolve(autocompleteCache.data);
  }
  return httpGet(BASE_URL + "/upload/autocomplete.js")
    .then(function (text) {
      // The file is: var allseries = [["Title","/anime/X/Title_(TV)"], ...];
      var m = text.match(/var\s+allseries\s*=\s*(\[.+?\]);/s);
      if (!m) throw new Error("Could not parse autocomplete.js");
      var arr = JSON.parse(m[1]);
      var index = {};
      arr.forEach(function (entry) {
        if (Array.isArray(entry) && entry.length >= 2) {
          var title = entry[0];
          var url = entry[1];
          if (!index[title.toLowerCase()]) {
            index[title.toLowerCase()] = { title: title, url: url };
          }
        }
      });
      console.log("[TokyoInsider] Autocomplete index: " + Object.keys(index).length + " titles");
      autocompleteCache.data = index;
      autocompleteCache.ts = Date.now();
      return index;
    })
    .catch(function (err) {
      console.log("[TokyoInsider] Autocomplete fetch failed: " + err.message);
      return {};
    });
}

function findAnimeUrl(index, title) {
  if (!index || !title) return null;
  var lower = title.toLowerCase();
  // Exact match
  if (index[lower]) return BASE_URL + index[lower].url;
  // Try with common suffixes
  var suffixes = [" (TV)", " (Movie)", " (OVA)", " (Special)", " (ONA)"];
  for (var i = 0; i < suffixes.length; i++) {
    if (index[lower + suffixes[i].toLowerCase()]) {
      return BASE_URL + index[lower + suffixes[i].toLowerCase()].url;
    }
  }
  // Substring match (first 20 chars)
  var prefix = lower.substring(0, 20);
  var keys = Object.keys(index);
  for (var j = 0; j < keys.length; j++) {
    if (keys[j].indexOf(prefix) === 0) {
      return BASE_URL + index[keys[j]].url;
    }
  }
  return null;
}

// ===== DOWNLOAD LINK EXTRACTION =====

function parseQuality(text) {
  var t = String(text).toLowerCase();
  if (t.indexOf("2160p") !== -1 || t.indexOf("4k") !== -1 || t.indexOf("uhd") !== -1) return "2160p";
  if (t.indexOf("1440p") !== -1) return "1440p";
  if (t.indexOf("1080p") !== -1) return "1080p";
  if (t.indexOf("720p") !== -1) return "720p";
  if (t.indexOf("480p") !== -1) return "480p";
  if (t.indexOf("360p") !== -1) return "360p";
  return "Unknown";
}

function parseFileSize(text) {
  var m = String(text).match(/([0-9.]+\s*[KMGT]B)/i);
  return m ? m[1].replace(/\s+/g, "").toUpperCase() : null;
}

function extractDownloadLinks(html, pageUrl) {
  var links = [];
  // TokyoInsider download links look like:
  //   <a href="/anime/X/Title_(TV)/episode_download/12345">Title - 1080p [1.2GB].mkv</a>
  // Or for movies:
  //   <a href="/download/12345">Title - 2160p [4GB].mkv</a>
  var re = /<a[^>]+href=["']([^"']*(?:episode_download|\/download\/)[^"']+)["'][^>]*>([^<]+<\/a>)/gi;
  var match;
  while ((match = re.exec(html)) !== null) {
    var href = match[1];
    var label = match[2].replace(/<[^>]+>/g, "").trim();
    if (!label) continue;
    var quality = parseQuality(label);
    var size = parseFileSize(label);
    var fullUrl = href.indexOf("http") === 0 ? href : BASE_URL + (href.charAt(0) === "/" ? "" : "/") + href;
    links.push({
      url: fullUrl,
      filename: label,
      quality: quality,
      size: size
    });
  }

  // Broader fallback: any .mkv / .mp4 link
  if (links.length === 0) {
    var broadRe = /<a[^>]+href=["']([^"']+)["'][^>]*>([^<]*?\.(?:mkv|mp4)[^<]*?)<\/a>/gi;
    while ((match = broadRe.exec(html)) !== null) {
      var href2 = match[1];
      var label2 = match[2].trim();
      if (!label2) continue;
      var q2 = parseQuality(label2);
      var s2 = parseFileSize(label2);
      var fullUrl2 = href2.indexOf("http") === 0 ? href2 : BASE_URL + (href2.charAt(0) === "/" ? "" : "/") + href2;
      links.push({
        url: fullUrl2,
        filename: label2,
        quality: q2,
        size: s2
      });
    }
  }

  // De-duplicate by URL
  var seen = {};
  return links.filter(function (l) {
    if (seen[l.url]) return false;
    seen[l.url] = true;
    return true;
  });
}

// ===== MAIN ENTRY =====

function getStreams(tmdbId, mediaType, seasonNum, episodeNum) {
  var isMovie = mediaType !== "tv";
  console.log(
    "[TokyoInsider] Request: tmdb=" + tmdbId + " type=" + mediaType +
    (isMovie ? "" : " S" + seasonNum + "E" + episodeNum)
  );

  if (!isMovie && !episodeNum) {
    console.log("[TokyoInsider] Episode number required for TV");
    return Promise.resolve([]);
  }

  return getTMDBDetails(tmdbId, mediaType)
    .then(function (info) {
      if (!info) return [];
      console.log("[TokyoInsider] TMDB: " + info.title + " (" + info.year + ")");

      return getAniListDetails(info.title, info.year).then(function (anilist) {
        // Build candidate title list (romaji > english > original > TMDB title)
        var candidates = [];
        if (anilist && anilist.romaji) candidates.push(anilist.romaji);
        if (info.title && (!anilist || info.title !== anilist.romaji)) candidates.push(info.title);
        if (anilist && anilist.english && anilist.english !== info.title && anilist.english !== anilist.romaji) {
          candidates.push(anilist.english);
        }
        if (info.originalTitle && info.originalTitle !== info.title && (!anilist || info.originalTitle !== anilist.romaji)) {
          candidates.push(info.originalTitle);
        }
        console.log("[TokyoInsider] Candidates: " + candidates.join(" | "));

        return getAutocompleteIndex().then(function (index) {
          // Find the anime URL from the autocomplete index
          var animeUrl = null;
          var usedTitle = null;
          for (var i = 0; i < candidates.length; i++) {
            animeUrl = findAnimeUrl(index, candidates[i]);
            if (animeUrl) {
              usedTitle = candidates[i];
              break;
            }
          }
          if (!animeUrl) {
            console.log("[TokyoInsider] No URL found in autocomplete index");
            return [];
          }
          console.log("[TokyoInsider] Found URL: " + animeUrl + " (using title: " + usedTitle + ")");

          // Build the page URL: for movies add /movie/1, for TV add /episode/N
          var pageUrl = animeUrl;
          if (isMovie) {
            pageUrl = animeUrl.replace(/\/?$/, "/movie/1");
          } else {
            pageUrl = animeUrl.replace(/\/?$/, "/episode/" + episodeNum);
          }
          console.log("[TokyoInsider] Fetching page (via Playwright for CF bypass): " + pageUrl);

          // Try Playwright first (handles CF Turnstile)
          return fetchViaPlaywright(pageUrl)
            .catch(function (err) {
              console.log("[TokyoInsider] Playwright failed: " + err.message);
              console.log("[TokyoInsider] Falling back to curl (may fail if CF-challenged)");
              return httpGet(pageUrl, { Referer: BASE_URL + "/" });
            })
            .then(function (html) {
              if (!html || html.length < 100) {
                console.log("[TokyoInsider] Empty page response");
                return [];
              }
              if (html.indexOf("Just a moment...") !== -1) {
                console.log("[TokyoInsider] Got Cloudflare challenge page - cannot extract streams");
                return [];
              }
              var links = extractDownloadLinks(html, pageUrl);
              console.log("[TokyoInsider] Extracted " + links.length + " download links");
              if (!links.length) return [];

              return links.map(function (l) {
                var titleLine = info.title;
                if (!isMovie) {
                  titleLine += " S" + String(seasonNum || 1).padStart(2, "0") +
                               "E" + String(episodeNum || 1).padStart(2, "0");
                }
                titleLine += " (" + info.year + ")";
                if (l.size) titleLine += " " + l.size;

                return {
                  name: PROVIDER_NAME + (l.quality !== "Unknown" ? " - " + l.quality : ""),
                  title: l.filename || titleLine,
                  url: l.url,
                  quality: l.quality,
                  size: l.size || undefined,
                  headers: {
                    "User-Agent": USER_AGENT,
                    Referer: BASE_URL + "/"
                  },
                  behaviorHints: {
                    bingeGroup: "tokyoinsider-" + l.quality
                  }
                };
              });
            });
        });
      });
    })
    .catch(function (err) {
      console.log("[TokyoInsider] Error: " + (err && err.message ? err.message : err));
      return [];
    });
}

module.exports = { getStreams: getStreams };
