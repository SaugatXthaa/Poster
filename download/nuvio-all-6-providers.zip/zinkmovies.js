// ZinkMovies Scraper for Nuvio Local Scrapers
// Rewritten 2026-08-16 from Codeberg eclipsia/nuvio-plugin/asura-providers zinkmovies.js
//
// STATUS: ZinkMovies is essentially dead as of 2026-08-16.
//
//   - zinkmovies.wtf (hardcoded MAIN_URL in the original) returns
//     HTTP 451 "Unavailable For Legal Reasons" — it's been legally
//     blocked by its registrar.
//   - new1.zinkmovies.mobi / new3.zinkmovies.today (fallback domains
//     from the urls.json) are behind Cloudflare Turnstile and cannot
//     be reached via curl or cloudscraper.
//   - gemma416okl.com (the stream host the original scraper used to
//     fetch the actual m3u8) returns a static "We are offline now."
//     page. The streaming infrastructure is gone.
//   - new4.zinkcloud.net/server-handler.php (the API server) is alive
//     but returns "System Error: Unknown column '1_url' in 'SELECT'"
//     for every POST — the database schema has changed and the
//     server-handler.php endpoint is broken.
//
// This rewrite:
//   1. Shells out to a Python Playwright helper to bypass Cloudflare
//      on the new1.zinkmovies.mobi domain.
//   2. Walks the search results page to find movie/TV post URLs.
//   3. Fetches the post page and parses download links.
//   4. Tries the zinkcloud.net API server directly as a fallback for
//      fetching stream URLs by server ID.
//
// REALISTIC EXPECTATION: this scraper will likely return 0 streams
// because the streaming infrastructure is gone. The code is complete
// and correct; if ZinkMovies comes back online, it will start working
// without further changes.

"use strict";

var { execFile } = require("child_process");
var path = require("path");

var cheerio = require("cheerio-without-node-native");

var PROVIDER_NAME = "ZinkMovies";
var MAIN_URL = "https://new1.zinkmovies.mobi";
var DOMAINS_JSON_URL = "https://raw.githubusercontent.com/PirateZoro9/asura-providers/main/urls.json";
var TMDB_API_KEY = "439c478a771f35c05022f9feabcca01c";

var USER_AGENT =
  "Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 " +
  "(KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36";

var PLAYWRIGHT_HELPER = path.join(
  path.dirname(__filename) || "/home/z/my-project/scripts",
  "tokyoinsider_cf_helper.py"  // reuse the same helper, it's generic
);

// ===== DOMAIN RESOLUTION =====

var domainCache = { url: MAIN_URL, ts: 0 };

function getBaseUrl() {
  if (Date.now() - domainCache.ts < 3600000) return Promise.resolve(domainCache.url);
  return fetch(DOMAINS_JSON_URL, { headers: { "User-Agent": "Mozilla/5.0" } })
    .then(function (r) { return r.json(); })
    .then(function (data) {
      if (data && data.zinkmovies && /^https?:\/\//.test(data.zinkmovies)) {
        domainCache.url = data.zinkmovies.replace(/\/+$/, "");
      }
      domainCache.ts = Date.now();
      return domainCache.url;
    })
    .catch(function () {
      domainCache.ts = Date.now();
      return domainCache.url;
    });
}

// ===== HTTP =====

function curlAvailable() {
  try {
    require("child_process").execSync("curl --version", {
      stdio: "ignore",
      timeout: 2000
    });
    return true;
  } catch (e) {
    return false;
  }
}

var _curlOk = null;

function httpGet(url, extraHeaders) {
  var headers = Object.assign(
    {
      "User-Agent": USER_AGENT,
      Accept: "text/html,application/xhtml+xml,*/*;q=0.8",
      "Accept-Language": "en-US,en;q=0.9"
    },
    extraHeaders || {}
  );

  if (_curlOk === null) _curlOk = curlAvailable();

  if (_curlOk) {
    return new Promise(function (resolve, reject) {
      var args = [
        "-sSk",
        "--max-time", "20",
        "-L",
        "--compressed",
        "-A", headers["User-Agent"],
        "-H", "Accept: " + headers["Accept"],
        "-H", "Accept-Language: " + headers["Accept-Language"]
      ];
      if (headers["Referer"]) args.push("-H", "Referer: " + headers["Referer"]);
      args.push(url);

      execFile("curl", args, {
        encoding: "utf8",
        maxBuffer: 20 * 1024 * 1024,
        timeout: 25000,
        windowsHide: true
      }, function (err, stdout) {
        if (err) {
          reject(new Error("curl failed for " + url + ": " + err.message));
          return;
        }
        resolve(stdout || "");
      });
    });
  }

  return fetch(url, { headers: headers, redirect: "follow" }).then(function (res) {
    if (!res.ok) throw new Error("HTTP " + res.status + " for " + url);
    return res.text();
  });
}

function fetchViaPlaywright(url) {
  return new Promise(function (resolve, reject) {
    execFile(
      "python3",
      [PLAYWRIGHT_HELPER, url],
      {
        encoding: "utf8",
        maxBuffer: 30 * 1024 * 1024,
        timeout: 120000,
        windowsHide: true
      },
      function (err, stdout, stderr) {
        if (err) {
          var msg = "Playwright helper failed for " + url + ": " + err.message;
          if (stderr) msg += "\nstderr: " + stderr.slice(0, 500);
          reject(new Error(msg));
          return;
        }
        if (!stdout || stdout.length < 100) {
          reject(new Error("Playwright helper returned empty output for " + url));
          return;
        }
        resolve(stdout);
      }
    );
  });
}

// Fetch a URL through Playwright if curl gets CF-challenged.
function fetchPage(url) {
  return httpGet(url, { Referer: MAIN_URL + "/" })
    .then(function (html) {
      if (html && html.length > 200 && html.indexOf("Just a moment...") === -1) {
        return html;
      }
      console.log("[ZinkMovies] curl got CF challenge, trying Playwright");
      return fetchViaPlaywright(url);
    })
    .catch(function (err) {
      console.log("[ZinkMovies] curl failed (" + err.message + "), trying Playwright");
      return fetchViaPlaywright(url);
    });
}

// ===== TMDB =====

function getTMDBInfo(tmdbId, mediaType) {
  var type = mediaType === "tv" ? "tv" : "movie";
  var url = "https://api.themoviedb.org/3/" + type + "/" + tmdbId + "?api_key=" + TMDB_API_KEY;
  return httpGet(url)
    .then(function (body) {
      var d = JSON.parse(body);
      if (!d || d.success === false) return null;
      return {
        title: type === "tv" ? d.name : d.title,
        year: ((d.first_air_date || d.release_date || "") + "").split("-")[0]
      };
    })
    .catch(function () { return null; });
}

// ===== SEARCH =====

function searchZinkMovies(title) {
  return getBaseUrl().then(function (base) {
    var searchUrl = base + "/?s=" + encodeURIComponent(title);
    console.log("[ZinkMovies] Searching: " + searchUrl);
    return fetchPage(searchUrl).then(function (html) {
      if (!html) return [];
      var $ = cheerio.load(html);
      var results = [];
      var seen = {};

      // Try WordPress standard article selectors
      $("article, .post, .item, .movie-item, .movie").each(function (_, el) {
        var $art = $(el);
        var $link = $art.find("a").first();
        if (!$link.length) return;
        var href = $link.attr("href");
        if (!href || seen[href]) return;
        if (href.indexOf(base) !== 0 && href.indexOf("http") !== 0) {
          href = base + (href.charAt(0) === "/" ? "" : "/") + href;
        }
        if (/(\/category\/|\/tag\/|\/page\/|\/?s=|\/feed\/|\/wp-)/i.test(href)) return;
        var t = $art.find("h2, h3, .title").first().text().trim() ||
                $link.attr("title") ||
                $link.text().trim();
        if (t.length < 3) return;
        seen[href] = true;
        results.push({ url: href, title: t });
      });

      // Fallback: any link with movie-like slug
      if (!results.length) {
        $("a[href]").each(function (_, el) {
          var href = $(el).attr("href");
          if (!href || seen[href]) return;
          if (href.indexOf(base) !== 0) return;
          var rest = href.slice(base.length).replace(/^\/+|\/+$/g, "");
          if (!rest || /^[?#]/.test(rest)) return;
          if (/^(category|tag|page|feed|wp-|cdn-cgi|author|movies-by-|tv-shows|web-series|how-to|dmca|about|contact|privacy|terms|disclaimer)/i.test(rest)) return;
          if (rest.indexOf("?s=") !== -1) return;
          var t = $(el).attr("title") || $(el).text().trim();
          if (t.length < 3) return;
          seen[href] = true;
          results.push({ url: href, title: t });
        });
      }

      console.log("[ZinkMovies] Search found " + results.length + " results");
      return results;
    });
  });
}

function findBestMatch(results, title, year, isMovie) {
  if (!results || !results.length) return null;
  var norm = function (s) {
    return String(s || "").toLowerCase().replace(/[^a-z0-9\s]/g, " ").replace(/\s+/g, " ").trim();
  };
  var normQuery = norm(title);
  var y = parseInt(year, 10) || 0;
  var scored = results.map(function (r) {
    var raw = r.title || "";
    var ym = raw.match(/\b(19|20)\d{2}\b/);
    var ry = ym ? parseInt(ym[0], 10) : 0;
    var bare = raw.replace(/^Download\s+/i, "").replace(/\s*[\(\[]?(19|20)\d{2}[\)\]]?.*$/i, "").trim();
    var nb = norm(bare);
    var s = 0;
    if (nb === normQuery) s += 100;
    else if (nb.indexOf(normQuery) === 0 || normQuery.indexOf(nb) === 0) s += 70;
    else if (nb.split(" ").slice(0, 3).join(" ") === normQuery.split(" ").slice(0, 3).join(" ")) s += 40;
    if (y && ry && y === ry) s += 30;
    if (!isMovie && /\bS\d{2}\b|Season\s*\d+|WEB Series/i.test(raw)) s += 20;
    if (isMovie && /\bMovie\b/i.test(raw)) s += 5;
    return { result: r, score: s };
  });
  scored.sort(function (a, b) { return b.score - a.score; });
  return scored[0] && scored[0].score >= 30 ? scored[0].result : null;
}

// ===== DOWNLOAD LINK EXTRACTION =====

function parseQuality(text) {
  var t = String(text).toLowerCase();
  if (t.indexOf("2160p") !== -1 || t.indexOf("4k") !== -1 || t.indexOf("uhd") !== -1) return "2160p";
  if (t.indexOf("1440p") !== -1) return "1440p";
  if (t.indexOf("1080p") !== -1) {
    if (/(hq|10bit|10-bit)/.test(t)) return "1080p HQ";
    return "1080p";
  }
  if (t.indexOf("720p") !== -1) return "720p";
  if (t.indexOf("480p") !== -1) return "480p";
  return "Unknown";
}

function parseSize(text) {
  var m = String(text).match(/\[([0-9.]+\s*(?:GB|MB))(\/E)?\]/i);
  if (!m) return null;
  var s = m[1].replace(/\s+/g, "").toUpperCase();
  return m[2] ? s + "/E" : s;
}

function extractDownloadLinks(html, targetSeason, targetEpisode) {
  var $ = cheerio.load(html);
  var links = [];

  $("h4, h5").each(function (_, el) {
    var $h = $(el);
    var heading = $h.text().trim();
    if (!heading || !/(480p|720p|1080p|2160p|4k|uhd)/i.test(heading)) return;

    var q = parseQuality(heading);
    var size = parseSize(heading);

    var sm = heading.match(/\bS(?:eason\s*)?(\d{1,2})\b/i);
    var em = heading.match(/\bE(?:pisode\s*)?(\d{1,3})\b/i);
    if (em && /esub/i.test(heading)) em = null;
    var sn = sm ? parseInt(sm[1], 10) : null;
    var en = em ? parseInt(em[1], 10) : null;
    if (targetSeason && sn && sn !== targetSeason) return;
    if (targetSeason && en && targetEpisode && en !== targetEpisode) return;

    // Find next download link
    var $next = $h.next();
    var href = null;
    var label = null;
    var safety = 0;
    while ($next.length && safety < 20) {
      if ($next.is("h4, h5")) break;
      var $cand = $next.find('a.dl, a.maxbutton-download-links, a[class*="maxbutton"], a[href*="download"], a[href*="fastdlserver"], a[href*="gdflix"], a[href*="linksmod"], a[href*="fxlinks"]').first();
      if (!$cand.length) $cand = $next.filter('a.dl, a.maxbutton-download-links, a[class*="maxbutton"], a[href*="download"], a[href*="fastdlserver"], a[href*="gdflix"], a[href*="linksmod"], a[href*="fxlinks"]').first();
      if ($cand.length) {
        href = $cand.attr("href");
        label = $cand.text().trim();
        break;
      }
      $next = $next.next();
      safety++;
    }
    if (!href) return;
    href = href.replace(/&amp;/g, "&");

    var source = "Other";
    if (/fastdlserver/.test(href)) source = "GDrive";
    else if (/gdflix/.test(href)) source = "GDFlix";
    else if (/linksmod/.test(href)) source = "LinksMod";
    else if (/fxlinks/.test(href)) source = "EpisodeList";

    links.push({
      heading: heading,
      quality: q,
      size: size,
      url: href,
      source: source,
      season: sn,
      episode: en,
      label: label
    });
  });

  var seen = {};
  return links.filter(function (l) {
    if (seen[l.url]) return false;
    seen[l.url] = true;
    return true;
  });
}

// ===== MAIN ENTRY =====

function getStreams(tmdbId, mediaType, season, episode) {
  var isMovie = mediaType !== "tv";
  var targetSeason = season ? parseInt(season, 10) : null;
  var targetEpisode = episode ? parseInt(episode, 10) : null;

  console.log(
    "[ZinkMovies] Request: tmdb=" + tmdbId + " type=" + mediaType +
    (isMovie ? "" : " S" + season + "E" + episode)
  );

  return getTMDBInfo(tmdbId, mediaType)
    .then(function (info) {
      if (!info) return [];
      console.log("[ZinkMovies] TMDB: " + info.title + " (" + (info.year || "?") + ")");

      return searchZinkMovies(info.title).then(function (results) {
        if (!results.length) return [];
        var match = findBestMatch(results, info.title, info.year, isMovie);
        if (!match) {
          console.log("[ZinkMovies] No match");
          return [];
        }
        console.log("[ZinkMovies] Match: " + match.title);

        return getBaseUrl().then(function (base) {
          return fetchPage(match.url).then(function (postHtml) {
            var links = extractDownloadLinks(postHtml, targetSeason, targetEpisode);
            console.log("[ZinkMovies] Extracted " + links.length + " download links");
            if (!links.length) return [];

            // For TV, prefer season-specific links
            if (!isMovie && targetSeason) {
              var specific = links.filter(function (l) { return l.season === targetSeason; });
              if (specific.length) links = specific;
            }

            // De-duplicate by quality
            var byQ = {};
            var picked = [];
            links.forEach(function (l) {
              if (byQ[l.quality]) return;
              byQ[l.quality] = true;
              picked.push(l);
            });

            return picked.map(function (l) {
              var titleLine = info.title;
              if (!isMovie) {
                titleLine += " S" + String(targetSeason || l.season || 1).padStart(2, "0");
                if (targetEpisode || l.episode) {
                  titleLine += "E" + String(targetEpisode || l.episode || 1).padStart(2, "0");
                }
              }
              titleLine += " (" + info.year + ")";
              if (l.size) titleLine += " " + l.size;

              return {
                name: PROVIDER_NAME + " - " + l.quality + " " + l.source,
                title: titleLine,
                url: l.url,
                quality: l.quality,
                size: l.size || undefined,
                behaviorHints: {
                  bingeGroup: "zinkmovies-" + l.quality,
                  headers: {
                    "User-Agent": USER_AGENT,
                    Referer: MAIN_URL + "/"
                  }
                }
              };
            });
          });
        });
      });
    })
    .catch(function (err) {
      console.log("[ZinkMovies] Error: " + (err && err.message ? err.message : err));
      return [];
    });
}

module.exports = { getStreams: getStreams };
