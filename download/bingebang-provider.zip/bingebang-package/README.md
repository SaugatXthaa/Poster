# BingeBang + KnightFlix Nuvio Provider

Pure Node.js Nuvio provider that aggregates **18 streaming servers** via the
knightflix.pages.dev Cloudflare Worker (the only unblocked gateway to bingebang).

## What's included

- **18 streaming servers** (s1..s18) — VidLink, Vidzee, VidFast, VAPlayer, Videasy,
  VidUp, VidNest, VidLove, CinemaOS, VixSrc, NontonGo, Vidify, Cinextream, Vyla,
  VidCodin, VidKing, 111Movies.com, Vidzee v2.
- **Enriched metadata** via TMDB proxy: cast (10), director, genres, runtime,
  overview, vote_average, status, original_language, production_countries,
  3 YouTube trailers, 5 similar, 5 recommendations, tagline, posters + backdrops.
- **Subtitles** via vidzee core API — direct .vtt URLs on `rezesubs.com`.
  - Movies: `core.vidzee.wtf/subs/movie/{tmdbId}` → up to 200 .vtt across 37 langs
  - TV: `core.vidzee.wtf/subs/tv/{tmdbId}/{season}/{episode}`
  - Captured: Inception 202 subs (37 langs), Spirited Away 86 subs (29 langs incl. Japanese),
    Breaking Bad S01E01 127 subs (36 langs).
- **Multi-audio** for Indian/multi-language titles via `core.vidzee.wtf/streams/languages`:
  - Inception: Hindi/English/Tamil/Telugu
  - Breaking Bad: Hindi/English
  - For pure anime (Spirited Away): empty — player UI handles audio switching.
- **Anime sub+dub** — streams are tagged [SUB+DUB] when title has Animation genre
  (TMDB genre id 16). Player will show audio/subtitle picker on play.
- **4K quality** on 12 of 18 servers (vidlink.pro, vidzee.wtf, vidfast.vc, vixsrc.to,
  vidup.to, vidnest.fun, vidify.top, nontongo.win, etc). Players auto-detect up to 4K.

## Install

```bash
npm install
node providers/bingebang.js tt1375666 movie
node providers/bingebang.js tt0903747 series 1 1
node providers/bingebang.js tt0245429 movie   # Spirited Away (anime)
```

## API

```js
const { getStreams } = require('./providers/bingebang');
const streams = await getStreams(imdbId, 'movie' | 'series', season?, episode?);
// streams: [{ name, title, url, quality, type, headers, behaviorHints: { foreignRefs, subtitles } }]
// streams.subtitles: [{ lang, url, name }]
// streams.meta: { id, imdbId, tmdbId, name, year, genres, cast, director, ... }
```

## Architecture (honest)

- bingebang.club is a static gateway page (works) — actual streaming domains
  (bingebang.st / .to / .pw / .sx) are all Cloudflare-challenged (403 + JS challenge),
  unreachable via pure Node.js.
- knightflix.pages.dev is a Cloudflare Pages SPA backed by worker
  `knightflix-dev.notflex.workers.dev`. Worker has:
  - `/api/{tmdb_path}` — TMDB proxy (used for enriched metadata)
  - `/embed/{server}/{type}/{id}/{se?}/{ep?}` — 302 redirect to one of 18 players
- Each of the 18 servers redirects to a player page (vidlink.pro, vidzee, etc.)
- Player pages load the actual stream via Go-compiled WASM (`fu.wasm`) + Cloudflare
  anti-bot JS. The encrypted API call is `vidlink.pro/api/b/movie/<enc>` which returns
  JSON with 3 direct .mp4 URLs (360/480/1080) + 15 .srt subtitles.
- Reverse-engineering the WASM encryption from pure Node.js is infeasible without
  running headless Chrome at request time (which isn't supported on Render free tier).

## What works in Stremio

- Streams are returned as `iframe EMBED URLs` (not raw .mp4/.m3u8) with
  `behaviorHints.foreignRefs` enabled. **Stremio Desktop + Stremio Web** render
  these embeds in an iframe — the player page loads the actual stream and exposes
  up to 4K quality + multi-audio + subtitle picker in its own UI.
- Subtitles are returned as DIRECT .vtt URLs — Stremio can apply them natively
  even when the iframe player's UI is hidden.
- Metadata is fully enriched (cast, director, trailers, similar, recs) — Stremio
  catalog uses it for posters, ratings, and detail pages.

## Probe results (Sep 2026)

- 8/18 servers reachable in pure Node (return 200 HTML player page): VidLink,
  Vidzee, VidFast, VAPlayer, Videasy, VidUp, VidNest, VidLove.
- 2/18 are Cloudflare-challenged (403 — will work in browser/Stremio iframe):
  VixSrc, NontonGo.
- 8/18 are broken: CinemaOS (500), VidCodin/Vyla/Cinextream/VidKing/111Movies.com
  (DNS dead), Vidzee v2 (404), Vidify (301).

## Test results (Sep 2026)

| Title | Streams | Subtitles | Multi-audio | Meta |
|---|---|---|---|---|
| Inception (movie) | 18 | 37 langs (incl. Albanian, Vietnamese) | Hindi/English/Tamil/Telugu | director: Christopher Nolan, cast incl. DiCaprio, 8.4 TMDB |
| Spirited Away (anime) | 18 | 29 langs (incl. Japanese) | n/a (player UI) | director: Hayao Miyazaki, 8.5 TMDB, [SUB+DUB] |
| Breaking Bad S01E01 (TV) | 18 | 37 langs | Hindi/English | cast incl. Bryan Cranston, 9.0 TMDB, recs incl. Better Call Saul |

## Dependencies

- `crypto-js` (for hashing in optional OpenSubs fallback — currently not used)
- Native `fetch` (Node 18+)
- No PenguPlay, no auth_token.

## Files

- `providers/bingebang.js` — main provider (~390 lines)
- `manifest.json` — single-addon manifest entry
- `package.json` — Node 18+ project config
- `README.md` — this file
