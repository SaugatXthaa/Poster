# NoctraTV Nuvio Provider

Pure Node.js Nuvio provider that authenticates with noctratv.com via ECDSA challenge
and returns the watch page URL with enriched TMDB metadata.

## What's included

- **ECDSA session establishment** — Node.js replicates the browser's Web Crypto flow:
  1. GET /api/player/v2/challenge → returns challengeId + nonce + issuedAt
  2. Generate ECDSA P-256 keypair via `crypto.subtle.generateKey`
  3. Sign `${challengeId}.${nonce}.${issuedAt}` with SHA-256 → base64url signature
  4. POST /api/player/v2/session with publicKey (JWK) + signature + fingerprint + capabilities
  5. Receive `{ token, sessionId, cookie }` valid for 10 minutes
- **Enriched TMDB metadata** via `/tmdb/{type}/{id}?append_to_response=credits,external_ids,videos,similar,recommendations,images,content_ratings`:
  - 10 cast members, director, genres, runtime, status, original language, production countries
  - 3 YouTube trailer keys, 5 similar titles, 5 recommendations, posters + backdrops
- **Best-effort subtitles** via `/api/subtitles/source?provider=vidapi&type={movie|tv}&tmdbId={id}` with session auth.
  (Often returns empty tracks until the WASM player has actively scraped the source.)
- **Anime [SUB+DUB] tag** auto-applied when TMDB genre 16 (Animation) is detected
- **4K quality** label (player will detect up to 4K on play)

## Honest limitation

- The actual stream URLs are resolved INSIDE a Go-compiled WebAssembly module
  (`index-BcEnMRZ3.js`, ~600 KB) running in the browser. The WASM module scrapes
  30+ third-party providers (vidapi, cinejoy, movienight, aether-* for Spanish/Turkish
  dubs, site-cinevaro-*, site-rive-*, etc).
- The WASM module is too complex to reproduce from Node.js (would need a V8 runtime
  + WASM interpreter at request time).
- **Streams returned are iframe EMBED URLs** (`https://noctratv.com/watch/{type}/{tmdbId}`).
  Stremio Desktop / Stremio Web render these in an iframe — the SPA loads, runs the WASM
  scraper, and plays the actual stream (up to 4K) inside the iframe.
- Subtitles endpoint works (HTTP 200) but returns empty tracks for most catalog queries
  because the WASM player hasn't pre-loaded subs for the title.

## Install

```bash
node providers/noctra.js tt1375666 movie
node providers/noctra.js tt0245429 movie    # Spirited Away (anime)
node providers/noctra.js tt0903747 series 1 1
```

## API

```js
const { getStreams } = require('./providers/noctra');
const streams = await getStreams(imdbId, 'movie' | 'series', season?, episode?);
// streams: [{ name, title, url, quality, type, headers, behaviorHints: { foreignRefs } }]
// streams.subtitles: [{ id, url, lang, name }] (usually empty)
// streams.meta: { id, imdbId, tmdbId, name, year, genres, cast, director, ... }
```

## Test results (Sep 2026)

| Title | Streams | Subs | Meta |
|---|---|---|---|
| Inception (movie) | 2 | 0 (WASM-bound) | Nolan, DiCaprio, 8.4 TMDB, 3 trailers, 5 similar |
| Spirited Away (anime) | 2 [SUB+DUB] | 0 | Miyazaki, 8.5 TMDB, 3 trailers, Ghibli recs |
| Breaking Bad S01E01 (TV) | 2 | 0 | Cranston, Paul, 9.0 TMDB, Better Call Saul in recs |

## Dependencies

- Node 18+ (for native `fetch` + `crypto.subtle`)
- No npm packages, no PenguPlay, no auth.

## Files

- `providers/noctra.js` — main provider (~290 lines)
- `manifest.json` — single-addon manifest entry
- `package.json` — Node 18+ project config
- `README.md` — this file
