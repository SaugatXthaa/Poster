# TOPX Posters+ · Worklog

## Round 3 (2026-10-29) — PostersPlus same-to-same integration

### Goal
- Sticky live preview above **and** below the 5 tabs (held in place while options scroll)
- Use **all** PostersPlus settings on top of topx/blvk; add extras not in either
- Keep the **PostersPlus poster URL format** so users can paste it directly into AIOMetadata poster providers
- End-to-end bug hunting, three-source same-to-same integration

### What was already in place (Rounds 1–2)
- 27 countries × 10 platforms matrix from TOPX/blvckTOP
- blvckTOP-style cover generator (Sharp + librsvg SVG composite)
- AES-256-GCM config token + dual Stremio/Nuvio manifest
- PostersPlus gold/black configurator with 5 tabs (Catalogs / Layout / Language / Style / Extras)
- 9-font registry, language-aware TMDB image selection, vignette pipeline
- `/poster` endpoint that accepted the PostersPlus URL surface

### What this round added / fixed
**1. UI — sticky preview verified**
- `.preview-stage` (top) + `.preview-stage.bottom-stage` (bottom) sit outside `.options-scroll`
- `body{overflow:hidden}` — only `.options-scroll` scrolls
- Verified by JS eval: scrolling options from y=0 → y=800 keeps `stageTop.y=38` and `stageBottom.y=566` unchanged
- Both stages refresh in place on every option change (live `/poster` re-render)

**2. AIOMetadata URL template — PostersPlus format match**
- `buildPosterUrl()` now emits `tmdb_id={tmdb_id?}&imdb_id={imdb_id?}&stremio_id={id}&type={type}&shape={shape}&rank={rank}` — exactly the form documented in PostersPlus `URL_REFERENCE.md § "Client templates"`
- `URLSearchParams` was URL-encoding the `{`, `}`, `?` chars; a final replace step decodes them back so the URL string matches PostersPlus verbatim

**3. `/poster` endpoint — full PostersPlus URL surface**
- AIOMetadata row-id unwrapping in `unwrapStremioId()`: `upnext_tt…`, `mdblist_upnext_tmdb:…`, `unwatched_tt…`, Stremio episode ids (`tt0903747:1:2`), `had:episode:tt…:6:6`
- Anime ID resolution (`kitsu:`, `anilist:`, `mal:`) via provider API → title → TMDB Animation search, cached per (provider, id)
- `resolveTmdbIdAndType()` returns both id and TMDB's actual type — when an IMDb id resolves to a TV show but the request said `type=movie`, **TMDB's type wins** (PostersPlus rule)
- Cache is now keyed per (id, type) with cross-type fallback so a wrong-type request finds the right title without re-query

**4. `/logo` endpoint — PostersPlus-compatible**
- `GET /logo?tmdb_id=…&type=…&lang=en` returns the best available title logo as PNG
- Uses `chooseLogoWithPriority()` (same priority/secondary scheme as `/poster`)
- Same anime ID + AIOMetadata row-id unwrapping as `/poster`
- Same type-mismatch handling (TMDB's type wins)

**5. Three-source integration (topx + blvk + PostersPlus)**
- TOPX: 27-country catalog matrix, multi-platform Top 10, country→language map
- blvckTOP: numbered cover generator, banner-style fresh background, language-aware artwork, provider palettes
- PostersPlus: URL format, parameter set (label_font, rating_display_mode, vignette_color_*, gradients, hide_*, sash_*, badge_*, trending_*, etc.), `/poster` + `/logo` endpoints, AIOMetadata placeholder semantics

### Test results (final verification)
```
1. Catalog pipeline (manifest → catalog → meta → top-cover): 13/13 PASS
2. /poster matrix (5 ids × 2 types × 2 shapes):               16/16 PASS
3. /logo endpoint:                                             4/4  PASS
4. AIOMetadata row id unwrapping:                              4/4  PASS
5. Stremio + Nuvio install URLs (canvas variants):             2/2  PASS
                                                            ──────
                                                            37/37 PASS (100%)

Extended /poster matrix (PostersPlus params + canvas × shape):
                                                            46/47 PASS
(The single 400 is the literal {tmdb_id?} placeholder URL — same
behavior as PostersPlus, which can't render a verbatim placeholder.)
```

### Files changed this round
- `tmdb.js` — `unwrapStremioId()`, `resolveAnimeId()`, `resolveTmdbIdAndType()`
- `server.js` — `/logo` endpoint; `/poster` uses `resolveTmdbIdAndType` + `effectiveType` for image fetch, details, coverKey
- `public/index.html` — `buildPosterUrl()` emits raw `{tmdb_id?}`/`{imdb_id?}`/`{id}`/`{type}`/`{shape}`/`{rank}` placeholders (PostersPlus verbatim form)

### How to use
1. `bash /home/z/my-project/scripts/topx-start.sh` (port 3471)
2. Open `http://localhost:3471/` — pick country + platforms + style
3. Click **Generate Manifest** → install Stremio or Nuvio from the deep links
4. The **AIOMetadata** URL box at the bottom is the PostersPlus-format poster URL — paste it into AIOMetadata → Poster Providers. AIOMetadata substitutes `{tmdb_id?}`, `{imdb_id?}`, `{id}`, `{type}`, `{shape}` per title, and your server renders each one.
5. Optional: also paste the matching `/logo?tmdb_id={tmdb_id?}&imdb_id={imdb_id?}&stremio_id={id}&type={type}` URL into AIOMetadata → Logo Providers.
