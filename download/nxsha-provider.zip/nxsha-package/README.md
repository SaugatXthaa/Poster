# Nxsha Nuvio Provider

Pure Node.js scraper for nxsha.space — no PenguPlay, no auth_token.
Returns direct playable HLS streams (multi-audio) + OpenSubtitles .srt downloads.

## Install
```bash
npm install crypto-js
```

## Files
- `providers/nxsha.js` — main provider (243 lines)
- `manifest.json` — addon manifest entry
- `package.json` — dependencies

## Usage (CLI test)
```bash
node providers/nxsha.js tt1375666 movie
node providers/nxsha.js tt0903747 tv 1 1
```

## API
```js
const { getStreams } = require('./providers/nxsha');
const streams = await getStreams(imdbId, 'movie' | 'tv', season?, episode?);
// streams: [{ name, title, url, quality, type, headers, behaviorHints }]
// streams.subtitles: [{ url, lang, name }]
```

## Test results (2026-09-28)
- Inception (movie): 28 streams + 29 subtitles, top 2 playable HLS
- Spirited Away (anime): 19 streams + 9 subtitles, top stream playable HLS

## Dependencies
- crypto-js (pure JS, works on Render free tier)
