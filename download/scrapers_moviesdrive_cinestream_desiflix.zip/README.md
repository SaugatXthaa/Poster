# MoviesDrive, CineStream, DesiFlix — Source Files (v2)

This zip contains 3 working scrapers + their Nuvio-compatible wrappers.

## 1. MoviesDrive (`moviesdrive_all_in_one.js`)
- **Domain**: https://new3.moviesdrive.christmas (current — was new2.moviesdrives.my before)
- **Source repos**: D3adlyRocket/Hindi-Nuvio + NuvioPlugin/All-in-One-Nuvio
- **Quality**: 4K (2160p), 1080p, 720p, 480p — all verified playable
- **Stream host**: Cloudflare workers (`*.workers.dev`) + PixelDrain mirrors
- **Movies**: Search by IMDB ID or title → hubcloud.cx search → Cloudflare worker URL
- **TV**: Search by title → mdrive.lol archive (per-season+quality) → episode URL → Cloudflare worker URL
- **Key discovery**: hubcloud.cx's Typesense search returns WRONG results for the
  full URL-encoded query. Searching for just "<title> <quality>" returns correct files.

## 2. CineStream (`cinestream_all_in_one.js`)
- **Original backend**: https://webstreamr.hayd.uk — **OFFICIALLY ARCHIVED**
- **Solution**: Wrapper that tries webstreamr first (in case it comes back),
  then delegates to working 4K-capable providers (moviesdrive, cineby, vidfast,
  dahmermovies-4k, uhdmovies, hindmoviez, hdhub4u, etc.)
- **Result**: 4K playable streams returned in the original CineStream format.

## 3. DesiFlix (`desiflix_all_in_one.js`) — v3
- **Domain**: https://manifest.desitvhub.eu.org (new official endpoint)
- **Quality**: 1080p max (the addon doesn't currently offer 4K)
- **Performance**: Stremio User-Agent + HTTP/1.1 = 0.6s response (vs 30s with browser UA)

## Usage

```bash
# Movies (with 4K)
node moviesdrive_all_in_one.js 693134 movie        # Dune Part Two (4K, 19GB)
node cinestream_all_in_one.js 693134 movie        # via 9 fallback providers
node desiflix_all_in_one.js 693134 movie          # via vixsrc.to playlist

# TV Shows
node moviesdrive_all_in_one.js 1396 tv 1 1        # Breaking Bad S01E01
node cinestream_all_in_one.js 1396 tv 1 1
node desiflix_all_in_one.js 1396 tv 1 1

# Search
node moviesdrive_all_in_one.js search "dune"
node desiflix_all_in_one.js search "dune"
```

## Files

| File | Description |
|------|-------------|
| `moviesdrive_all_in_one.js` | MoviesDrive direct stream extractor (4K playable) |
| `cinestream_all_in_one.js` | CineStream wrapper (webstreamr dead, delegates to 4K providers) |
| `desiflix_all_in_one.js` | DesiFlix v3 (manifest.desitvhub.eu.org) |
| `nuvio_moviesdrive.js` | Nuvio-compatible wrapper for moviesdrive |
| `nuvio_cinestream.js` | Nuvio-compatible wrapper for cinestream |
| `nuvio_desiflix.js` | Nuvio-compatible wrapper for desiflix |
| `README.md` | This file |

## Test Results (verified end-to-end)

### MoviesDrive
- ✅ Dune Part Two (movie): 4 streams — 2160p (4K, 19GB), 1080p, 720p, 480p
- ✅ Breaking Bad S01E01 (TV): 3 streams — 1080p, 720p, 480p
- ✅ All streams verified: HTTP 206, video/x-matroska, Range support
- ✅ Multiple Cloudflare worker domains: hubcloud.downloadservers.workers.dev,
  fancy-mountain-7dfb.terapiyo232.workers.dev, bsnl-route.neetflixcdn.workers.dev,
  purple-tooth-dbcf.voleje528933.workers.dev, hubcloudfiles.cehoy32277.workers.dev, etc.

### CineStream (wrapper)
- ✅ Dune Part Two: 50+ streams (from 9 fallback providers, 4K included)
- ✅ Breaking Bad S01E01: 36 streams (from 8 providers)
- ✅ Zero torrent/magnet streams

### DesiFlix (v3)
- ✅ Dune Part Two: 1 stream (1080p English)
- ✅ Breaking Bad S01E01: 1 stream (1080p English)
- ✅ vixsrc.to playlist URL with proper Referer headers
- ✅ Response time: ~0.6s (Stremio UA + HTTP/1.1)
