/**
 * Creepy — Adult Streaming Addon for Stremio/Nuvio
 * ==================================================
 * 4 sources, each with its own named catalog:
 *   1. XPrimeHub  — xprimehub.bond  (movies, web series, short films)
 *   2. Damplips   — damplips.com    (adult short films / clips)
 *   3. Qorno      — qorno.com       (aggregator: 23+ source sites)
 *   4. FullPorn   — fullporn.to     (full-length adult videos, up to 4K)
 *
 * Render free tier compatible:
 *   - Uses process.env.PORT (Render sets this automatically)
 *   - Health check endpoint at /
 *   - Graceful error handling (never crashes on request errors)
 *   - curl via child_process (curl is pre-installed on Render's Linux)
 *
 * Deploy:
 *   1. Push to GitHub
 *   2. Create new Web Service on Render, connect repo
 *   3. Build Command: npm install
 *   4. Start Command: node addon.js
 *   5. Add addon in Stremio: https://your-app.onrender.com/manifest.json
 */
'use strict';

const express = require('express');
const cors = require('cors');

const xprime = require('./nuvio_xprimehub');
const damplips = require('./nuvio_damplips');
const qorno = require('./nuvio_qorno');
const fullporn = require('./nuvio_fullporn');

const app = express();
const PORT = process.env.PORT || 7000;
const HOST = '0.0.0.0';

app.use(cors());
app.use(express.json());

// ─── Manifest ────────────────────────────────────────────────────────────────
const manifest = {
  id: 'com.creepy.addon',
  version: '1.0.0',
  name: 'Creepy',
  description: '4 sources: XPrimeHub, Damplips, Qorno, FullPorn. Movies, clips, and full-length videos up to 4K.',
  logo: 'https://raw.githubusercontent.com/google/material-design-icons/master/src/device/ic_cast_for_education_48px.svg',
  types: ['movie'],
  resources: ['catalog', 'meta', 'stream'],
  catalogs: [
    // XPrimeHub
    {
      type: 'movie',
      id: 'xprimehub',
      name: 'XPrimeHub',
      extra: [
        { name: 'search', isRequired: false },
        { name: 'skip', isRequired: false },
      ],
    },
    {
      type: 'movie',
      id: 'xprimehub_latest',
      name: 'XPrimeHub Latest',
      extra: [{ name: 'skip', isRequired: false }],
    },
    // Damplips
    {
      type: 'movie',
      id: 'damplips',
      name: 'Damplips',
      extra: [
        { name: 'search', isRequired: false },
        { name: 'genre', isRequired: false, options: [
          'amateur-porn', 'anal-sex', 'asian-girls', 'babes', 'big-black-cocks',
          'big-tits', 'college-girls', 'creampie', 'foursome', 'girlfriends',
          'girls-masturbate', 'hardcore', 'hot-girls', 'hugecocks', 'latina-girls',
          'lesbians', 'naked-girls', 'naked-women', 'sexy-girls',
          'teen-sex', 'threesome', 'young-girls',
        ]},
        { name: 'skip', isRequired: false },
      ],
    },
    {
      type: 'movie',
      id: 'damplips_latest',
      name: 'Damplips Latest',
      extra: [{ name: 'skip', isRequired: false }],
    },
    // Qorno
    {
      type: 'movie',
      id: 'qorno',
      name: 'Qorno',
      extra: [
        { name: 'search', isRequired: false },
        { name: 'genre', isRequired: false, options: [
          'japanese', 'blonde', 'teen', 'milf', 'anal', 'asian', 'ebony',
          'latina', 'lesbian', 'threesome', 'creampie', 'big-tits', 'cumshot',
          'blowjob', 'amateur', 'public', 'bondage',
        ]},
        { name: 'skip', isRequired: false },
      ],
    },
    {
      type: 'movie',
      id: 'qorno_latest',
      name: 'Qorno Latest',
      extra: [{ name: 'skip', isRequired: false }],
    },
    // FullPorn
    {
      type: 'movie',
      id: 'fullporn',
      name: 'FullPorn',
      extra: [
        { name: 'search', isRequired: false },
        { name: 'genre', isRequired: false, options: ['latest-updates', 'most-popular', 'top-rated'] },
        { name: 'skip', isRequired: false },
      ],
    },
    {
      type: 'movie',
      id: 'fullporn_latest',
      name: 'FullPorn Latest',
      extra: [{ name: 'skip', isRequired: false }],
    },
  ],
  idPrefixes: ['xprimehub:', 'damplips:', 'qorno:', 'fullporn:'],
};

// ─── Health Check (required by Render) ───────────────────────────────────────
app.get('/', (req, res) => {
  res.json({
    name: 'Creepy',
    status: 'running',
    manifest: '/manifest.json',
    catalogs: 8,
    sources: ['XPrimeHub', 'Damplips', 'Qorno', 'FullPorn'],
  });
});

app.get('/health', (req, res) => {
  res.json({ status: 'ok' });
});

// ─── Manifest ────────────────────────────────────────────────────────────────
app.get('/manifest.json', (req, res) => {
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.json(manifest);
});

// ─── Catalog Handler ─────────────────────────────────────────────────────────
app.get('/catalog/:type/:id.json', async (req, res) => {
  const { type, id } = req.params;
  const search = req.query.search || '';
  const genre = req.query.genre || '';
  const skip = parseInt(req.query.skip || '0');
  const page = Math.floor(skip / 50) + 1;

  console.log(`[Catalog] ${id} | search="${search}" genre="${genre}" skip=${skip} page=${page}`);

  try {
    let metas = [];

    if (id === 'xprimehub' || id === 'xprimehub_latest') {
      if (search) {
        const entries = await xprime.searchCatalog(search, 100);
        metas = entries.map(e => ({
          id: `xprimehub:${e.slug}`,
          type: 'movie',
          name: e.parsed.title,
          description: `${e.parsed.title}${e.parsed.year ? ' (' + e.parsed.year + ')' : ''} — ${e.parsed.language} ${e.parsed.qualities.join('/')}`,
          releaseInfo: e.parsed.year ? String(e.parsed.year) : '',
          genres: [e.parsed.language],
        }));
      } else {
        const result = await xprime.getCatalogMetas({ page, pageSize: 50 });
        metas = result.metas || [];
      }
    } else if (id === 'damplips' || id === 'damplips_latest') {
      if (search) {
        const entries = await damplips.searchCatalog(search, 100);
        metas = entries.map(e => ({
          id: `damplips:${e.id}`,
          type: 'movie',
          name: e.title,
          poster: e.poster,
          description: `${e.title}${e.date ? ' — ' + e.date : ''}${e.category ? ' [' + e.category + ']' : ''}`,
          releaseInfo: e.date || '',
          genres: e.category ? [e.category] : [],
        }));
      } else if (genre) {
        const streams = await damplips.getStreams(null, 'movie', null, null, { category: genre });
        const seen = new Set();
        metas = streams.filter(s => {
          if (seen.has(s.meta.postId)) return false;
          seen.add(s.meta.postId);
          return true;
        }).map(s => ({
          id: `damplips:${s.meta.postId}`,
          type: 'movie',
          name: s.meta.title,
          poster: s.poster || s.meta.poster,
          description: s.title,
          genres: s.meta.category ? [s.meta.category] : [],
        }));
      } else {
        const result = await damplips.getCatalogMetas({ page, pageSize: 50 });
        metas = result.metas || [];
      }
    } else if (id === 'qorno' || id === 'qorno_latest') {
      if (search) {
        const cards = await qorno.searchCatalog(search, 100);
        metas = cards.map(c => ({
          id: `qorno:${c.id}`,
          type: 'movie',
          name: c.title,
          poster: c.thumbnail,
          description: `${c.title}${c.duration ? ' [' + c.duration + ']' : ''}${c.source ? ' — ' + c.source : ''}`,
          releaseInfo: c.duration || '',
          genres: [c.source],
        }));
      } else if (genre) {
        const cards = await qorno.fetchByCategory(genre, page);
        metas = cards.map(c => ({
          id: `qorno:${c.id}`,
          type: 'movie',
          name: c.title,
          poster: c.thumbnail,
          description: `${c.title}${c.duration ? ' [' + c.duration + ']' : ''}`,
          releaseInfo: c.duration || '',
          genres: [c.source],
        }));
      } else {
        const result = await qorno.getCatalogMetas({ page, pageSize: 50 });
        metas = result.metas || [];
      }
    } else if (id === 'fullporn' || id === 'fullporn_latest') {
      if (search) {
        const cards = await fullporn.searchCatalog(search, 100);
        metas = cards.map(c => ({
          id: `fullporn:${c.id}`,
          type: 'movie',
          name: c.title,
          poster: c.thumbnail,
          description: `${c.title}${c.duration ? ' [' + c.duration + ']' : ''}${c.isHd ? ' HD' : ''}`,
          releaseInfo: c.duration || '',
          genres: c.isHd ? ['HD'] : [],
        }));
      } else if (genre) {
        const cards = await fullporn.fetchByCategory(genre, page);
        metas = cards.map(c => ({
          id: `fullporn:${c.id}`,
          type: 'movie',
          name: c.title,
          poster: c.thumbnail,
          description: `${c.title}${c.duration ? ' [' + c.duration + ']' : ''}${c.isHd ? ' HD' : ''}`,
          releaseInfo: c.duration || '',
          genres: c.isHd ? ['HD'] : [],
        }));
      } else {
        const result = await fullporn.getCatalogMetas({ page, pageSize: 50 });
        metas = result.metas || [];
      }
    }

    res.setHeader('Access-Control-Allow-Origin', '*');
    res.json({ metas: metas || [] });
  } catch (e) {
    console.error(`[Catalog] Error for ${id}:`, e.message);
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.json({ metas: [] });
  }
});

// ─── Meta Handler ────────────────────────────────────────────────────────────
app.get('/meta/:type/:id.json', async (req, res) => {
  const { type, id } = req.params;
  console.log(`[Meta] ${id}`);

  try {
    const [prefix, ...rest] = id.split(':');
    const realId = rest.join(':');
    let meta = null;

    if (prefix === 'xprimehub') {
      const parsed = xprime.parsePostSlug(realId);
      meta = {
        id, type: 'movie',
        name: parsed.title,
        description: `${parsed.title}${parsed.year ? ' (' + parsed.year + ')' : ''} — ${parsed.language} ${parsed.qualities.join('/')}`,
        releaseInfo: parsed.year ? String(parsed.year) : '',
        genres: [parsed.language],
      };
    } else if (prefix === 'damplips') {
      const streams = await damplips.getStreamsByPostId(realId);
      if (streams[0]) {
        meta = {
          id, type: 'movie',
          name: streams[0].meta.title,
          poster: streams[0].poster || streams[0].meta.poster,
          description: streams[0].title,
          genres: streams[0].meta.category ? [streams[0].meta.category] : [],
        };
      }
    } else if (prefix === 'qorno') {
      const cards = await qorno.getCatalog();
      const card = cards.find(c => c.id === realId);
      if (card) {
        meta = {
          id, type: 'movie',
          name: card.title,
          poster: card.thumbnail,
          description: `${card.title}${card.duration ? ' [' + card.duration + ']' : ''}${card.source ? ' — ' + card.source : ''}`,
          releaseInfo: card.duration || '',
          genres: [card.source],
        };
      }
    } else if (prefix === 'fullporn') {
      const cards = await fullporn.getCatalog();
      const card = cards.find(c => c.id === realId);
      if (card) {
        meta = {
          id, type: 'movie',
          name: card.title,
          poster: card.thumbnail,
          description: `${card.title}${card.duration ? ' [' + card.duration + ']' : ''}${card.isHd ? ' HD' : ''}`,
          releaseInfo: card.duration || '',
          genres: card.isHd ? ['HD'] : [],
        };
      }
    }

    if (!meta) {
      res.status(404).json({ error: 'Not found' });
      return;
    }

    res.setHeader('Access-Control-Allow-Origin', '*');
    res.json({ meta });
  } catch (e) {
    console.error(`[Meta] Error:`, e.message);
    res.status(500).json({ error: e.message });
  }
});

// ─── Stream Handler ──────────────────────────────────────────────────────────
app.get('/stream/:type/:id.json', async (req, res) => {
  const { type, id } = req.params;
  console.log(`[Stream] ${id}`);

  try {
    const [prefix, ...rest] = id.split(':');
    const realId = rest.join(':');
    let streams = [];

    if (prefix === 'xprimehub') {
      streams = await xprime.getStreamsBySlug(realId);
    } else if (prefix === 'damplips') {
      streams = await damplips.getStreamsByPostId(realId);
    } else if (prefix === 'qorno') {
      const cards = await qorno.getCatalog();
      let card = cards.find(c => c.id === realId);
      if (!card) {
        const searchCards = await qorno.searchCatalog(realId, 20);
        card = searchCards.find(c => c.id === realId);
      }
      if (card) {
        streams = await qorno.getStreams(null, 'movie', null, null, { search: card.title });
        const matched = streams.filter(s => s.meta && s.meta.videoId === realId);
        streams = matched.length > 0 ? matched : streams.slice(0, 3);
      }
    } else if (prefix === 'fullporn') {
      const cards = await fullporn.getCatalog();
      let card = cards.find(c => c.id === realId);
      if (!card) {
        const searchCards = await fullporn.searchCatalog(realId, 20);
        card = searchCards.find(c => c.id === realId);
      }
      if (card) {
        streams = await fullporn.extractStreams(card);
      } else {
        streams = await fullporn.getStreamsByVideoId(realId);
      }
    }

    console.log(`[Stream] Returning ${streams.length} stream(s) for ${id}`);
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.json({ streams: streams || [] });
  } catch (e) {
    console.error(`[Stream] Error:`, e.message);
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.json({ streams: [] });
  }
});

// ─── Catch-all (prevents 404 crashes) ────────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({ error: 'Not found', path: req.path });
});

// ─── Process error handlers (prevent crashes) ────────────────────────────────
process.on('unhandledRejection', (reason) => {
  console.error('[Process] Unhandled Rejection:', reason);
});
process.on('uncaughtException', (err) => {
  console.error('[Process] Uncaught Exception:', err);
});

// ─── Start Server ────────────────────────────────────────────────────────────
app.listen(PORT, HOST, () => {
  console.log('');
  console.log('  ╔══════════════════════════════════════════════════╗');
  console.log('  ║  Creepy — Stremio/Nuvio Addon                   ║');
  console.log('  ╚══════════════════════════════════════════════════╝');
  console.log('');
  console.log(`  Server:   http://${HOST}:${PORT}`);
  console.log(`  Manifest: http://localhost:${PORT}/manifest.json`);
  console.log('');
  console.log('  Catalogs:');
  console.log('    1. XPrimeHub  — Movies, Web Series, Short Films');
  console.log('    2. Damplips   — Adult Short Films / Clips');
  console.log('    3. Qorno      — Aggregator (23+ sources)');
  console.log('    4. FullPorn   — Full-Length Videos (up to 4K)');
  console.log('');
});
