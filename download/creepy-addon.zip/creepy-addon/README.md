# Creepy

Adult streaming addon for **Stremio** and **Nuvio** with 4 sources, each with its own named catalog and real working streams.

## Sources

| # | Source | Content | Max Quality |
|---|--------|---------|-------------|
| 1 | XPrimeHub | Movies, Web Series, Short Films | 1080p |
| 2 | Damplips | Adult Short Films / Clips | 720p |
| 3 | Qorno | Aggregator (23+ source sites) | 720p |
| 4 | FullPorn | Full-Length Videos | 4K (2160p) |

## Deploy on Render (Free Tier)

1. Fork this repo on GitHub
2. Go to [render.com](https://render.com) → **New** → **Web Service**
3. Connect your GitHub repo
4. Settings (auto-filled from `render.yaml`):
   - **Build Command:** `npm install`
   - **Start Command:** `node addon.js`
   - **Plan:** Free
5. Click **Create Web Service**
6. Wait for deployment (~1 min)
7. Your addon URL: `https://your-app-name.onrender.com/manifest.json`

## Add to Stremio

1. Open Stremio
2. **Settings** → **Addons** → **Add Addon**
3. Enter your Render URL: `https://your-app-name.onrender.com/manifest.json`
4. Click **Install**

## Add to Nuvio

1. Open Nuvio
2. **Settings** → **Plugins/Scrapers**
3. Add: `https://your-app-name.onrender.com/manifest.json`

## Run Locally

```bash
npm install
node addon.js
```

Then add `http://localhost:7000/manifest.json` in Stremio.

## Catalogs

| Catalog ID | Name | Search | Genre Filter |
|-----------|------|--------|-------------|
| xprimehub | XPrimeHub | ✓ | — |
| xprimehub_latest | XPrimeHub Latest | — | — |
| damplips | Damplips | ✓ | 22 categories |
| damplips_latest | Damplips Latest | — | — |
| qorno | Qorno | ✓ | 17 categories |
| qorno_latest | Qorno Latest | — | — |
| fullporn | FullPorn | ✓ | latest/popular/top-rated |
| fullporn_latest | FullPorn Latest | — | — |

## API Endpoints

| Endpoint | Description |
|----------|-------------|
| `GET /` | Health check + addon info |
| `GET /health` | Render health check |
| `GET /manifest.json` | Stremio manifest |
| `GET /catalog/movie/:id.json` | Browse catalog |
| `GET /catalog/movie/:id.json?search=X` | Search catalog |
| `GET /catalog/movie/:id.json?genre=X` | Filter by genre |
| `GET /meta/movie/:id.json` | Video metadata |
| `GET /stream/movie/:id.json` | Stream URLs |

## Technical

- **Pure Node.js** — no Playwright, no browser
- **CF Bypass**: Uses `curl` (pre-installed on Render/Linux) to bypass Cloudflare TLS fingerprinting
- **Render Free Tier**: Uses `process.env.PORT`, health check at `/health`, graceful error handling
- **Caching**: Catalogs cached for 6 hours

## License

For personal use only.
