# CloudMovieZ + MultiShows Nuvio Provider

Pure Node.js Nuvio provider that scrapes c1.cloudmoviez.shop (DooPlay WordPress theme)
for direct download links. TMDB-enriched metadata included.

## What's included

- **Movie streams**: scrape `/movies/{slug}/` page → parse `<tr id='link-N'>` rows from
  `links_table` → follow `/links/{slug}/` redirect → extract `continue-btn` href
  (vcloud.zip / gdrive / gdflix.dev / mega.nz URLs).
- **TV streams**: scrape `/tvshows/{slug}/` page → parse `cmz-row-card cmz-filter-item`
  items → decode `?file=<base64>` URLs → JSON contains `{"url":"https://gdflix.dev/file/{id}",...}`.
  Filter by season/episode from filename patterns like `S01E01`.
- **Multi-audio labels**: parse from filename ("Dual Audio", "HIN-JAP", "Hindi-English")
  → tagged as [DUAL-AUDIO] or [language-code] in stream name.
- **4K detection**: 2160p / 4K / UHD in filename → labeled "4K" in stream name.
  HDR detected separately and labeled [HDR].
- **Anime SUB+DUB**: TMDB genre 16 (Animation) auto-applies [SUB+DUB] tag.
  Files typically have Japanese+Hindi or Japanese+English dual audio (dubbed).
- **Enriched metadata**: TMDB query with append_to_response for cast (10), director,
  3 trailers, 5 similar, 5 recommendations, posters + backdrops.
- **Playability probing**: each stream URL probed with HTTP HEAD (Range bytes=0-1).
  Direct playable URLs (HTTP 200/206 + video content-type) marked `notWebReady: false`.
  CF-challenged URLs (HTTP 403 "Just a moment...") marked `notWebReady: true` +
  `foreignRefs` for Stremio iframe rendering.

## Honest limitations

- **multishows.top is fully anti-bot-blocked**: Returns "One moment, please..."
  interstitial for ALL Node.js requests. Anti-bot challenge verifies webdriver,
  userAgent, and appVersion. ALL API endpoints return HTTP 403 from Node.js.
  Cannot be bypassed without a real browser + stealth plugin.
  → The provider uses c1.cloudmoviez.shop only (the cloudmoviez.top redirect target).
- **Stream URLs are on file hosts (vcloud.zip, gdflix.dev)** that are also
  Cloudflare-challenged. They return HTTP 403 to Node.js requests.
  Stremio Desktop/Web's iframe player (real browser webview) can render them —
  the user clicks "Continue" on the file host page to start the actual download.
- **No subtitle endpoint**: cloudmoviez doesn't provide subtitle URLs. The .mkv
  files typically have embedded subtitle tracks (Stremio detects them on play).
- **Some movie link pages fall back to `/file/{slug}/`** (404 fallback when streams
  were removed). Returns 0 streams in those cases (honest).
- **No 4K detection for some movies** if the quality field is just "1080p x264"
  (no explicit 4K stream available for that title).

## Test results (Sep 2026)

| Title | Streams | Quality | Audio | Meta |
|---|---|---|---|---|
| Inception (movie) | 3 | 1080p/720p/480p x264 | Dual Audio [Hindi-English] | Nolan, DiCaprio, 8.4 TMDB |
| A Shop for Killers (TV S01E01) | 10 | 4K HDR + 1080p + 720p | DUAL-AUDIO (DSNP WEB-DL) | Lee Dong-wook, 8.5 TMDB |
| Spirited Away (anime) | 0 (link fallbacks) | - | - | Miyazaki, 8.5 TMDB [ANIME] |
| Breaking Bad S01E01 (TV) | 0 (not on cloudmoviez) | - | - | Cranston, Paul, 9.0 TMDB |

## Probe results (Sep 2026)

- All vcloud.zip and gdflix.dev URLs return HTTP 403 (CF challenge) from Node.js.
- All streams correctly marked as iframe embeds with `foreignRefs`.
- Stremio Desktop/Web iframe player can render them.

## Install

```bash
node providers/cloudmoviez.js tt1375666 movie           # Inception
node providers/cloudmoviez.js 215072 tv 1 1             # A Shop for Killers (TMDB ID)
node providers/cloudmoviez.js tt0245429 movie           # Spirited Away (returns 0 — links removed)
```

## API

```js
const { getStreams } = require('./providers/cloudmoviez');
const streams = await getStreams(imdbIdOrTmdbId, 'movie' | 'series', season?, episode?);
// streams: [{ name, title, url, quality, type, headers, behaviorHints }]
// streams.meta: { id, imdbId, tmdbId, name, year, genres, cast, director, ... }
```

## Dependencies

- Node 18+ (for native fetch)
- No npm packages, no PenguPlay, no auth.

## Files

- `providers/cloudmoviez.js` — main provider (~470 lines)
- `manifest.json` — single-addon manifest entry
- `package.json` — Node 18+ project config
- `README.md` — this file
